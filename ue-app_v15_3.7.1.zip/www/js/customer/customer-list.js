 $(document).ready(function() {
    $("#header").load('layouts/header.html')
    $("#sidebar").load('layouts/sidebar.html')
    $("#footer").load('layouts/footer.html')    
    var access_token = localStorage.getItem('access_token')        
    function loadInitial(argument) {
        $.ajax({
            method: "GET",
            url: base_url+"api/customer",
            dataType: "json",
            processData: false,
            contentType: false,
            cache: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                'Accept': 'application/json',
                "Authorization": "Bearer " + access_token
            },
            success: function(response) {
                $("#_listView").empty()
                $("#customer").addClass('active')
                for (count = 0; count < response.length; count++) {
                    let phone2 = '';
                    if(response[count].phone_2 != 'NA'){
                       phone2 = '<span>' +
                                '<a class="call-number 12" data-number="'+response[count].phone_2+'">' +
                                '<div class="icon-box bg-secondary">' +
                                '<i class="bi bi-telephone" style="position: absolute;"></i>' +
                                '<p style="font-size: 12px;position: relative;margin-top: 5px;margin-left: 10px;">2</p>'+
                                '</div>' +
                                '</a>' 
                                '</span>' 
                    }
                    $("#_listView").append('<li>' +
                        '<div class="item">' +
                        '<img src="img/avatar1.png" alt="image" class="image">' +
                        '<div class="in">' +
                        '<div id="customerDetails" style="width: 100%;" data-cname="'+response[count].f_name+' '+response[count].s_name+'" data-shopname="'+response[count].shop_name+'" data-phone1="'+response[count].phone_1+'" data-cid="'+response[count].customer_id+'" data-ctype="'+response[count].customer_type+'" data-locality="'+response[count].locality+'" data-balance="'+response[count].balance+'" data-bs-toggle="offcanvas" data-bs-target="#actionModal">' +
                        '<header class="text-primary text-capitalize" >'+response[count].f_name+' '+response[count].s_name+'</header>'+
                        '<div class="text-capitalize">'+response[count].shop_name+'</div>'+
                        '<footer class="text-capitalize">'+ response[count].locality+ '</footer>' +
                        '</div>' +
                        '<span>' +
                        '<a class="call-number 1" data-number="'+response[count].phone_1+'">' +
                        '<div class="icon-box bg-secondary">' +
                        '<i class="bi bi-telephone" style="position: absolute;"></i>' +
                        '<p style="font-size: 12px;position: relative;margin-top: 5px;margin-left: 10px;">1</p>'+
                        '</div>' +
                        '</a>' +

                        '</span>' +
                            phone2 +
                        '</div>' +
                        '</div>' +
                        '</li>')
                }
                $(".pageTitle").text('Customer')
                $('#loader').remove();
            }, //success end
            error: function(badRes,t) {
                errortoast(badRes.statusText)
                if(navigator.onLine == false){
                    loadInitial()
                }
                if (badRes.status > 200) {
                    loadInitial()                            
                }
                if (badRes.status == 401) {
                    localStorage.removeItem('access_token');
                    if(localStorage.getItem('email')){
                        window.location.href = "auth/unlock.html"
                    }
                    else{
                        window.location.href = "auth/login.html"
                    }
                    
                }
            }, //ajax error end
        }) //ajax end
    }
    loadInitial()

    $(document).on('click','#customerDetails',function(event){
        event.preventDefault()
       $('#actiontitle').text($(this).data('cname'))
       localStorage.setItem('customerID', $(this).data('cid'))
       localStorage.setItem('customerType', $(this).data('ctype'))
       localStorage.setItem('customerName',$(this).data('cname'))
       localStorage.setItem('shopName',$(this).data('shopname'))
       localStorage.setItem('phoneNo1',$(this).data('phone1'))
       localStorage.setItem('locality',$(this).data('locality'))
       localStorage.setItem('balance',$(this).data('balance'))
    })

    $(document).on("keyup","#search_input", function() {
        var value = $(this).val().toLowerCase();
        searchFunction(value)
    });  

    $(document).on('click','#headerCloseBtn',function(event){
        event.preventDefault()
        $("#search_input").val('')
        $("#search_input").attr('placeholder','Search...')
        $("#search").removeClass('show')
        var value = ''
        searchFunction(value)
    })

    function searchFunction(value) {
        $("#_listView .item").filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });
    }
    $(document).on("click","a.call-number", function() {
        let number = $(this).data('number')
       window.location.href = "tel:+91"+number
    }); 

    $(document).on('click','#deleteCustomer',function(){
        $("#actionModal").modal('hide')
        $('.modal-body').html("<span class='text-capitalize'>Are you sure to delete this customer <span class='text-danger'>"+localStorage.getItem("customerName")+"</span> ??</span>")                
        $("#errorModalFooter").remove()
        $(".error-modal-content").append('<div class="modal-footer" id="errorModalFooter">'+
                '<div class="btn-inline">'+
                    '<button class="btn btn-text-danger" id="sureDelBtn">'+
                        '<i class="bi bi-trash"></i>'+
                        'DELETE </button>'+
                    '<button class="btn btn-text-primary" data-bs-dismiss="modal">'+
                        '<i class="bi bi-x-circle"></i>'+
                       ' CLOSE </button>'+
                '</div>'+
            '</div>')
        $("#errorModal").modal('show')
    })

    $(document).on('click','#sureDelBtn',function(event){
        event.preventDefault()
        sureDelteCustomer()
    })

    function sureDelteCustomer() {
        let customerId = localStorage.getItem('customerID')
        $.ajax({
            method: "GET",
            url: base_url+"api/customer/delete/"+customerId,
            dataType: "json",
            processData: false,
            contentType: false,
            cache: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                'Accept': 'application/json',
                "Authorization": "Bearer " + access_token
            },
            success:function(response){
                $("#errorModal").modal('hide')
                if(response.success){
                    notification(response.success)
                    $('#loader').show();
                    loadInitial()
                }
                if(response.error){
                    notification(response.error)
                }
            },
            error:function(badRes){
                errortoast(badRes.statusText)
                if(navigator.onLine == false){
                    sureDelteCustomer()
                }
                if (badRes.status > 200) {
                    sureDelteCustomer()                            
                }
                if (badRes.status == 401) {
                    localStorage.removeItem('access_token');
                    if(localStorage.getItem('email')){
                        window.location.href = "auth/unlock.html"
                    }
                    else{
                        window.location.href = "auth/login.html"
                    }
                    
                }
            },
        })// ajax end
    }
})
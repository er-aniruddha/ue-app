$(document).ready(function(){
    $("#header").load('layouts/header.html')
    $("#sidebar").load('layouts/sidebar.html')
    $("#footer").load('layouts/footer.html')
    
    document.addEventListener("backbutton", function(e){
       if(window.location.hash === ""){
           e.preventDefault();
           navigator.app.exitApp();
       }
       else {
           navigator.app.backHistory();
       }
    }, false);

    var startDate = moment().subtract(1,'year').format("YYYY-MM-DD")
    var endDate = moment().format("YYYY-MM-DD")
    $(".sdate").val(startDate)
    $(".edate").val(endDate)

    loadInitial()
    function loadInitial() {
    	$.ajax({
            method: "GET",
            url: base_url+"api/dashboard",
            dataType: "json",
            data:{startDate:startDate,endDate:endDate},
            contentType: false,
            cache: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                'Accept': 'application/json',
                "Authorization": "Bearer " + access_token
            },
            success: function(res) {
            	$('#loader').hide();
                $('#appHeader').removeAttr('id');
   				$('#searchBtn').remove( );
                $('#sales-amount').html(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(res.sales))
                $('#purchase-amount').html(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(res.purchase))
                $('#crnote-amount').html(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(res.crnote))
                $('#expense-amount').html(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(res.expense))
                $('#due-amount').html(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(res.due)+'<i class="bi bi-box-arrow-up-right" style="float: right;font-size: 15px;margin-top: 5px;"></i>')
                $('#pay-amount').html(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(res.pay)+'<i class="bi bi-box-arrow-up-right" style="float: right;font-size: 15px;margin-top: 5px;"></i>')
                $('#loan-amount').html(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(res.loanBal)+'<i class="bi bi-box-arrow-up-right" style="float: right;font-size: 15px;margin-top: 5px;"></i>')
                $('#emi-amount').html(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(res.totalEmi)+'<i class="bi bi-box-arrow-up-right" style="float: right;font-size: 15px;margin-top: 5px;"></i>')
            },
            error:function(badRes){
                errortoast(badRes.statusText)
                if(navigator.onLine == false){
                    loadInitial()
                }
                if (badRes.status > 200) {
                    loadInitial()                            
                }
                if (badRes.status == 401) {
                    localStorage.removeItem('access_token');
                    if(localStorage.getItem('email')){
                        window.location.href = "auth/unlock.html"
                    }
                    else{
                        window.location.href = "auth/login.html"
                    }
                    
                }
            }
        })
    }

    duDatepicker('.sdate', {
        format: 'yyyy-mm-dd',cancelBtn: true,minDate:moment("2021-01-01"),maxDate:'today',
        // disabledDays: ['Sat', 'Sun'],
        events: {
            dateChanged: function (res) { 
            	startDate = res.date    
            	getValue() 
            }
        }
    })
    duDatepicker('.edate', {
        format: 'yyyy-mm-dd',cancelBtn: true,minDate:moment("2021-01-01"),maxDate:'today',
        // disabledDays: ['Sat', 'Sun'],
        events: {
            dateChanged: function (res) { 
            	endDate = res.date     
            	getValue()
            }
        }
    })
    var ri;
    /* to get value of endDate when startDate value change of card start */
    $(document).on('click','.sdate',function(event){
        ri = $(this).data('name') 
       	endDate = $(this).parents().eq(3).children().eq(1).children().children().children().eq(1).val()
    }) 
    /* to get value of endDate when startDate value change of card end */
    /* to get value of startDate when endDate value change of card start */
    $(document).on('click','.edate',function(event){
        ri = $(this).data('name') 
       	startDate = $(this).parents().eq(3).children().eq(0).children().children().children().eq(1).val()
    }) 
    /* to get value of startDate when endDate value change of card end */

    var dashboard_routes = [
        { "id":"sales", "name": base_url+"api/dashboard/sales" },
        { "id":"purchase", "name": base_url+"api/dashboard/purchase" },
        { "id":"crnote", "name": base_url+"api/dashboard/crnote" },
        { "id":"expense", "name": base_url+"api/dashboard/expense" }
    ];

    function getValue() {
    	$("#loader").show()
    	let url = dashboard_routes.filter(elem => {
            return elem.id == ri;
        })
        $.ajax({
            method: "GET",
            url: url[0].name,
            dataType: "json",
            data:{startDate:startDate,endDate:endDate},
            contentType: false,
            cache: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                'Accept': 'application/json',
                "Authorization": "Bearer " + access_token
            },
            success: function(res) {
            	$("#loader").hide()
                $('#'+ri+'-amount').html(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(res))
            },
            error:function(badRes){
                errortoast(badRes.statusText)
                if(navigator.onLine == false){
                    getValue()
                }
                if (badRes.status > 200) {
                    getValue()                            
                }
                if (badRes.status == 401) {
                    localStorage.removeItem('access_token');
                    if(localStorage.getItem('email')){
                        window.location.href = "auth/unlock.html"
                    }
                    else{
                        window.location.href = "auth/login.html"
                    }
                    
                }
            }
        })
    }
})
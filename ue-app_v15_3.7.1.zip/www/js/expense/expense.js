 $(document).ready(function() {
    $("#header").load('layouts/header.html')
    $("#sidebar").load('layouts/sidebar.html')
    $("#footer").load('layouts/footer.html') 
    var allExpense  

    function loadInitial(argument) {
        $.ajax({
            method: "GET",
            url: base_url+"api/expense",
            dataType: "json",
            processData: false,
            contentType: false,
            cache: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                'Accept': 'application/json',
                "Authorization": "Bearer " + access_token
            },
            success: function(response) {
                allExpense = response
                $("#expense_table tbody").empty()
            	for(let count=0; count < response.length; count++){
            		$('#expense_table tbody').append('<tr>'+
                                '<td>'+moment(response[count].date).format('DD-MM-YYYY')+'</td>'+
                                '<td class="inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(response[count].total)+'</td>'+
                                '<td>'+
                                	'<button class="btn btn-outline-warning shadowed btn-sm mb-1" data-id="'+response[count].expense_id+'" data-date="'+moment(response[count].date).format('DD-MM-YYYY')+'" data-bs-toggle="offcanvas" data-bs-target="#actionModal" id="actionBtn">'+
                                		'Action'+
                                	'</button>'+
                                '</td>'+
                            '</tr>')
            	}
            	$("#loader").remove() 
                $(".pageTitle").text('Expense')
                bottomExpenseDetails()
            }, //success end
            error: function(badRes,t) {
                errortoast(badRes.statusText)
                if(navigator.onLine == false){
                    loadInitial()
                }
                if (badRes.status > 200) {
                    loadInitial()                            
                }
                if (badRes.status == 401) {
                    localStorage.removeItem('access_token');
                    if(localStorage.getItem('email')){
                        window.location.href = "auth/unlock.html"
                    }
                    else{
                        window.location.href = "auth/login.html"
                    }
                    
                }
            }, //ajax error end
        })
    }
    loadInitial()

    function bottomExpenseDetails() {
        $.ajax({
            method: "GET",
            url: base_url+"api/expense/details",
            dataType: "json",
            processData: false,
            contentType: false,
            cache: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                'Accept': 'application/json',
                "Authorization": "Bearer " + access_token
            },
            success: function(response) {
                $("#_1YR").text(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(response.oneYearExpense))
                $("#_1MNTH").text(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(response.oneMonthExpense))
                $("#_7d").text(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(response.sevenDaysExpense))

            }, //success end
            error: function(badRes,t) {
                errortoast(badRes.statusText)
                if(navigator.onLine == false){
                    loadInitial()
                }
                if (badRes.status > 200) {
                    loadInitial()                            
                }
                if (badRes.status == 401) {
                    localStorage.removeItem('access_token');
                    if(localStorage.getItem('email')){
                        window.location.href = "auth/unlock.html"
                    }
                    else{
                        window.location.href = "auth/login.html"
                    }
                    
                }
            }, //ajax error end
        })
    }

    $(document).on("keyup","#search_input", function() {
        var value = $(this).val().toLowerCase();
        searchFunction(value)
    });

    $(document).on('click','#headerCloseBtn',function(event){
        event.preventDefault()
        $("#search_input").val('')
        $("#search_input").attr('placeholder','Search...')
        $("#search").removeClass('show')
        var value = ''
        searchFunction(value)
    })

    function searchFunction(value) {
        $("#expense_table tbody tr").filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });
    }

    var expense_id,expense_date;

    $(document).on('click','#addExpense',function(event){
        event.preventDefault()
        $("#expenseForm .text-danger").html("")
        $('#expenseForm')[0].reset();
        var postData = new FormData($("#expenseForm")[0]);
        $("#date").attr('disabled',false)
        $("#expenseModal").modal('show')
        $('#saveBtn').show()
        $('#updateBtn').hide()
        $(".modal-title").text("Add Expense") 
    })

    /*------ To check decimal value -----*/
    $('#fuel, #travelling ,#transport, #tiffin, #room_rent, #salary, #extra_exp').keypress(function(event) {
        if ((event.which != 46 || $(this).val().indexOf('.') != -1)&&(event.which < 48 || event.which > 57)) {
        //alert('hello');
            if((event.which != 46 || $(this).val().indexOf('.') != -1)){
            alert('Multiple Decimals are not allowed');
          }
          event.preventDefault();
       }
    });
    /*------ To check decimal value -----*/

    /*----- Total calculation ------*/
    $(document).delegate('#fuel, #travelling ,#transport, #tiffin, #room_rent, #salary, #extra_exp', 'keyup', function() {
        let fuel = $("#fuel").val()
        let travelling = $("#travelling").val()
        let transport = $("#transport").val()
        let tiffin = $("#tiffin").val()
        let room_rent = $("#room_rent").val()
        let salary = $("#salary").val()
        let extra_exp = $("#extra_exp").val()
        let total = (+fuel)+(+travelling)+(+transport)+(+tiffin)+(+room_rent)+(+salary)+(+extra_exp)
        $("#total").val(total.toFixed(2))
    });
    /*----- Total calculation ------*/

    /*----- save expense form -----*/
    $("#expenseForm").on('click','#saveBtn',function(event){
        event.preventDefault()
        $("#expenseForm .text-danger").html("")
        $("#loader").show()
        var postData = new FormData($("#expenseForm")[0]);
        saveExpense(postData)
    })

    function saveExpense(postData) {
        $("#loader").show()
        $.ajax({
            method: "POST",
            url: base_url+"api/expense/create",
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: postData,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                'Accept': 'application/json',
                "Authorization": "Bearer " + access_token
            },
            success: function(response) {
                $("#loader").hide()
                if (response.errors) {
                    if(response.errors.date){
                        $("#date_error").text(response.errors.date[0])
                    }
                    if(response.errors.fuel){
                        $("#fuel_error").text(response.errors.fuel[0])
                    }
                    if(response.errors.travelling){
                        $("#travelling_error").text(response.errors.travelling[0])
                    }
                    if(response.errors.transport){
                        $("#transport_error").text(response.errors.transport[0])
                    }
                    if(response.errors.tiffin){
                        $("#tiffin_error").text(response.errors.tiffin[0])
                    }
                    if(response.errors.room_rent){
                        $("#room_rent_error").text(response.errors.room_rent[0])
                    }
                    if(response.errors.salary){
                        $("#salary_error").text(response.errors.salary[0])
                    }
                    if(response.errors.extra_exp){
                        $("#extra_exp_error").text(response.errors.extra_exp[0])
                    }
                    if(response.errors.total){
                        $("#total_error").text(response.errors.total[0])
                    }
                    if(response.errors.remarks){
                        $("#remarks_error").text(response.errors.remarks[0])
                    }
                }                    
                if(response.success == "OK") {
                    notification(response.message)  
                    $("#expenseModal").modal('hide')
                    $('input').attr('value' , '')
                    loadInitial()
                    bottomExpenseDetails()
                }
            }, //success end
            error:function(badRes){
                errortoast(badRes.statusText)
                if(navigator.onLine == false){
                    saveExpense()
                }
                if (badRes.status > 200) { 
                    saveExpense()                       
                }
                if (badRes.status == 401) {
                    localStorage.removeItem('access_token');
                    if(localStorage.getItem('email')){
                        window.location.href = "auth/unlock.html"
                    }
                    else{
                        window.location.href = "auth/login.html"
                    }
                    
                }
            }, //error end
        }) //ajax end
    }        
    /*----- save expense form -----*/

    /*----- on cancl button click -----*/
    $(document).on('click','#closeBtn',function(event){
        event.preventDefault()
        $("#expenseModal").modal('hide')
    })
    /*----- on cancl button click -----*/

    duDatepicker('#date', {
        format: 'dd-mm-yyyy', clearBtn: true, minDate:moment("2022-01-01"),maxDate: 'today'
        // disabledDays: ['Sat', 'Sun'],
    })
    $(document).on('click',"#actionBtn",function(event){
        event.preventDefault()
        expense_date = $(this).data('date')
        $("#actiontitle").text('Expense date: '+expense_date)
        expense_id =  $(this).data('id')

    })

    $(document).on('click','#view',function(event){
        event.preventDefault()
        let thisExpense = allExpense.filter(elem => {
            return elem.expense_id == expense_id;
        })       
        $("#expenseForm .text-danger").html("")          
        $("#date").attr('disabled',true)
        $(".modal-title").text("Expense Details")        
        $('#saveBtn').hide()
        $('#updateBtn').hide()
        showModal(thisExpense)
    })

    /*----- update expense form -----*/
    $(document).on('click','#edit',function(event){
        event.preventDefault()
        let thisExpense = allExpense.filter(elem => {
            return elem.expense_id == expense_id;
        }) 
        $("#expenseForm .text-danger").html("")
        $('#expenseForm')[0].reset();
        $("#date").attr('disabled',false)
        $(".modal-title").text("Edit Expense")      
        $('#saveBtn').hide()
        $('#updateBtn').show()      
        showModal(thisExpense)
    })

    $("#expenseForm").on('click','#updateBtn',function(event){
        event.preventDefault()
        $("#expenseForm .text-danger").html("")
        $("#loader").show()
        var postData = new FormData($("#expenseForm")[0]);
        updateExpense(postData)
    })

    function updateExpense(postData) {
        $.ajax({
            method: "POST",
            url: base_url+"api/expense/update",
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: postData,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                'Accept': 'application/json',
                "Authorization": "Bearer " + access_token
            },
            success: function(response) {
                $("#loader").hide()
                if (response.errors) {
                    if(response.errors.date){
                        $("#date_error").text(response.errors.date[0])
                    }
                    if(response.errors.fuel){
                        $("#fuel_error").text(response.errors.fuel[0])
                    }
                    if(response.errors.travelling){
                        $("#travelling_error").text(response.errors.travelling[0])
                    }
                    if(response.errors.transport){
                        $("#transport_error").text(response.errors.transport[0])
                    }
                    if(response.errors.tiffin){
                        $("#tiffin_error").text(response.errors.tiffin[0])
                    }
                    if(response.errors.room_rent){
                        $("#room_rent_error").text(response.errors.room_rent[0])
                    }
                    if(response.errors.salary){
                        $("#salary_error").text(response.errors.salary[0])
                    }
                    if(response.errors.extra_exp){
                        $("#extra_exp_error").text(response.errors.extra_exp[0])
                    }
                    if(response.errors.total){
                        $("#total_error").text(response.errors.total[0])
                    }
                    if(response.errors.remarks){
                        $("#remarks_error").text(response.errors.remarks[0])
                    }
                }                    
                else {
                    notification(response.message)  
                    $("#expenseModal").modal('hide')
                    $('input').attr('value' , '')
                    loadInitial()
                    bottomExpenseDetails()
                }
            }, //success end
            error:function(badRes){
                errortoast(badRes.statusText)
                if(navigator.onLine == false){
                    updateExpense()
                }
                if (badRes.status > 200) { 
                    updateExpense()                       
                }
                if (badRes.status == 401) {
                    localStorage.removeItem('access_token');
                    if(localStorage.getItem('email')){
                        window.location.href = "../auth/unlock.html"
                    }
                    else{
                        window.location.href = "../auth/login.html"
                    }
                    
                }
            }, //error end
        }) //ajax end
    }        
    /*----- update expense form -----*/

    function showModal(thisExpense) {                
        $("#date").val(moment(thisExpense[0].date).format('DD-MM-YYYY'))
        $("#fuel").val(thisExpense[0].fuel)
        $("#travelling").val(thisExpense[0].travelling)
        $("#transport").val(thisExpense[0].transport)
        $("#tiffin").val(thisExpense[0].tiffin)
        $("#room_rent").val(thisExpense[0].room_rent)
        $("#salary").val(thisExpense[0].salary)
        $("#extra_exp").val(thisExpense[0].extra_exp)
        $("#total").val(thisExpense[0].total)
        $("#remarks").val(thisExpense[0].remarks)
        $("#expense_id").val(thisExpense[0].expense_id)
        $("#expenseModal").modal("show") 
        $(".error-text").html("")
    }

    var delExpId
    $(document).on('click','#deleteExpense',function(event){
        event.preventDefault()        
        $('#errorModal .modal-body').html("Are you sure to delete this expense: "+expense_date+" ??")                
        $("#errorModalFooter").remove()
        $(".error-modal-content").append('<div class="modal-footer" id="errorModalFooter">'+
                '<div class="btn-inline">'+
                    '<button class="btn btn-text-danger" id="sureDelBtn">'+
                        '<ion-icon name="trash-outline" role="img" class="md hydrated" aria-label="trash outline"></ion-icon>'+
                        'DELETE </button>'+
                    '<button class="btn btn-text-primary" data-bs-dismiss="modal">'+
                        '<ion-icon name="close-circle-outline" role="img" class="md hydrated" aria-label="close-circle-outline"></ion-icon>'+
                       ' CLOSE </button>'+
                '</div>'+
            '</div>')
         $(".modal-title").text("Delete Expense")       
        $("#errorModal").modal('show')
    })

    $(document).on('click','#sureDelBtn',function(event){
        event.preventDefault()
        sureDeleteExpense()
    })

    function sureDeleteExpense() {
        $.ajax({
            method: "GET",
            url: base_url+"api/expense/delete/"+expense_id,
            dataType: "json",
            processData: false,
            contentType: false,
            cache: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                'Accept': 'application/json',
                "Authorization": "Bearer " + access_token
            },
            success:function(response){
                $("#errorModal").modal('hide')
                if(response.success){
                    notification(response.success)   
                    $('#loader').show();
                    loadInitial()
                    bottomExpenseDetails()
                }
                if(response.error){
                    notification(response.error) 
                }
            },
            error:function(badRes){
                errortoast(badRes.statusText)
                if(navigator.onLine == false){
                    sureDeleteExpense()
                }
                if (badRes.status > 200) {
                    sureDeleteExpense()                            
                }
                if (badRes.status == 401) {
                    localStorage.removeItem('access_token');
                    if(localStorage.getItem('email')){
                        window.location.href = "auth/unlock.html"
                    }
                    else{
                        window.location.href = "auth/login.html"
                    }
                    
                }
            },
        })// ajax end
    }
    duDatepicker('#date_range', {
        range: true, format: 'mmmm d, yyyy', outFormat: 'yyyy-mm-dd', 
        clearBtn: true, theme: 'blue', minDate:moment("2022-01-01"),maxDate: 'today',
        // inline: true
        events: {
            dateChanged: function (data) {       
                window.startDate = new Date(data._dateFrom).getFullYear()+'-'+(new Date(data._dateFrom).getMonth()+1)+'-'+new Date(data._dateFrom).getDate();
                window.endDate = new Date(data._dateTo).getFullYear()+'-'+(new Date(data._dateTo).getMonth()+1)+'-'+new Date(data._dateTo).getDate();
                dateRangeDetails()
            }
        }
    })

    function dateRangeDetails(argument) {
        $.ajax({
            method: "GET",
            url: base_url+"api/expense/date/range",
            dataType: "json",
            data:{ startDate: startDate, endDate: endDate},
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                'Accept': 'application/json',
                "Authorization": "Bearer " + access_token
            },
            success: function(response) {
                var expense = response.expense
                var totalExpense = response.totalExpense
                $("#expense_table tbody").empty()
                for(let count=0; count < expense.length; count++){
                    $('#expense_table tbody').append('<tr>'+
                                '<td style="text-aling: center;">'+moment(expense[count].date).format('DD-MM-YYYY')+'</td>'+
                                '<td style="text-aling: center;" class="inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(expense[count].total)+'</td>'+
                                '<td style="text-aling: center;">'+
                                    '<button class="btn btn-outline-warning shadowed btn-sm mb-1" data-id="'+expense[count].expense_id+'" data-date="'+moment(expense[count].date).format('DD-MM-YYYY')+'" data-bs-toggle="offcanvas" data-bs-target="#actionModal" id="actionBtn">'+
                                        'Action'+
                                    '</button>'+
                                '</td>'+
                            '</tr>')
                }
                $("#_TotalExp").text(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(totalExpense))
            }, //success end
            error: function(badRes,t) {
                errortoast(badRes.statusText)
                if(navigator.onLine == false){
                    loadInitial()
                }
                if (badRes.status > 200) {
                    loadInitial()                            
                }
                if (badRes.status == 401) {
                    localStorage.removeItem('access_token');
                    if(localStorage.getItem('email')){
                        window.location.href = "auth/unlock.html"
                    }
                    else{
                        window.location.href = "auth/login.html"
                    }
                    
                }
            }, //ajax error end
        })
    }
})
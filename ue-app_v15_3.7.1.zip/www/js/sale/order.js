$(document).ready(function() {   
    $("#sidebar").load('layouts/sidebar.html')
    $("#footer").load('layouts/footer.html')
    var products;
    var inoviceBottomForm = {};
    /*------- input[type='number'] can't be null -------*/
    const numInputs = document.querySelectorAll('input[type=number]')
    numInputs.forEach(function(input) {
      input.addEventListener('change', function(e) {
        if (e.target.value == '') {
          e.target.value = 0
          totalCalculation()
        }
      })
    })
    /*------- input[type='number'] can't be null -------*/

    /*------ To prevent multi decimal input start ------*/
    $('#round_off, #last_discount').keypress(function(event) {
        if ((event.which != 46 || $(this).val().indexOf('.') != -1)&&(event.which < 48 || event.which > 57)) {
        //alert('hello');
            if((event.which != 46 || $(this).val().indexOf('.') != -1)){
            alert('Multiple Decimals are not allowed');
          }
          event.preventDefault();
       }
    });
    /*------ To prevent multi decimal input edn ------*/

    var access_token = localStorage.getItem('access_token')
    var customerId = localStorage.getItem('customerID')
    var customerType = localStorage.getItem('customerType')
    var customerName = localStorage.getItem('customerName')
    var shopName = localStorage.getItem('shopName')
    var phone1 = localStorage.getItem('phoneNo1')
    var locality = localStorage.getItem('locality')
    var prevBalance = localStorage.getItem('balance')
    $("#_prevBalance").html(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(prevBalance))

    $('.invoice-to').html('<h4 class="text-capitalize"><i class="bi bi-shop"></i>&nbsp;' + shopName + '</h4>' +
        '<h3 class="text-capitalize">' + customerName + '</h3>' +
        '<p class="text-capitalize"><i class="bi bi-telephone"></i>&nbsp;' + phone1 + '</p>' +
        '<p class="text-capitalize"><i class="bi bi-geo-alt"></i>&nbsp;' + locality + '</p>')

    function productList() {
        $.ajax({
            method: "GET",
            url: base_url + "api/product",
            dataType: "json",
            processData: false,
            contentType: false,
            cache: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                'Accept': 'application/json',
                "Authorization": "Bearer " + access_token
            },
            success: function(response) {
                products = response.product
                productTable()
                $('#loader').hide();
            },
            error: function(badRes) {
                errortoast(badRes.statusText)
                if (navigator.onLine == false) {
                    productList();
                }
                if (badRes.status > 200) {
                    productList();
                }
                if (badRes.status == 401) {
                    localStorage.removeItem('access_token');
                    if (localStorage.getItem('email')) {
                        window.location.href = "auth/unlock.html"
                    } else {
                        window.location.href = "auth/login.html"
                    }

                }
            },
        })
    } // orderList function end
    productList()

    function productTable(argument) {
        for (let count = 0; count < products.length; count++) {
            if (customerType == 1) { /// this is retail rate
                $("#product_table tbody").append('<tr>' +
                    '<td><small class="text-sm">' + products[count].product_name + ' - ' + products[count].brand_name + '</small></td>' +
                    '<td class="inr-sign">' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(products[count].r_pri_unit_rate) + ' &#92; ' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(products[count].r_sec_unit_rate) + '</td>' +
                    '<td>' + products[count].in_hand_stock_primary + ' &#92; ' + products[count].in_hand_stock_second + '</td>' +
                    '<td><button type="button" class="btn btn-icon btn-sm btn-danger me-1 mb-1 addToCartBtn" id="' + products[count].product_id + '" data-punitid="' + products[count].primary_unit + '" data-sunitid="' + products[count].secondary_unit + '" data-punitname="' + products[count].primary_unit_name + '" data-sunitname="' + products[count].secondary_unit_name + '" data-punitrate="' + products[count].r_pri_unit_rate + '" data-sunitrate="' + products[count].r_sec_unit_rate + '">' +
                    '<i class="bi bi-plus-lg"></i></button></td>' +
                    '</tr>')
            }
            if (customerType == 2) { /// this is distributor rate
                $("#product_table tbody").append('<tr>' +
                    '<td><small class="text-sm">' + products[count].product_name + ' - ' + products[count].brand_name + '</small></td>' +
                    '<td class="inr-sign">' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(products[count].d_pri_unit_rate) + ' &#92; ' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(products[count].d_sec_unit_rate) + '</td>' +
                    '<td>' + products[count].in_hand_stock_primary + ' &#92; ' + products[count].in_hand_stock_second + '</td>' +
                    '<td><button type="button" class="btn btn-icon btn-sm btn-danger me-1 mb-1 addToCartBtn" id="' + products[count].product_id + '" data-punitid="' + products[count].primary_unit + '" data-sunitid="' + products[count].secondary_unit + '" data-punitname="' + products[count].primary_unit_name + '" data-sunitname="' + products[count].secondary_unit_name + '" data-punitrate="' + products[count].d_pri_unit_rate + '" data-sunitrate="' + products[count].d_sec_unit_rate + '">'+
                    '<i class="bi bi-plus-lg"></i></button></td>' +
                    '</tr>')
            }
        }
    }

    

    var selectProductId;
    $(document).on('click', '.addToCartBtn', function(event) {
        event.preventDefault()      
        let modalTitle = $(this).parent().parent().children(':nth-child(1)').children().text()
        $('.modal-title').text(modalTitle)
        $("#_unit").empty().append()
        $("#_unit").append('<option class="text-capitalize" data-uid="' + $(this).data('punitid') + '" data-uname="' + $(this).data('punitname') + '" data-mrp="' + $(this).data('punitrate') + '">' + $(this).data('punitname') + '</option>' +
                           '<option class="text-capitalize" data-uid="' + $(this).data('sunitid') + '" data-uname="' + $(this).data('sunitname') + '" data-mrp="' + $(this).data('sunitrate') + '">' + $(this).data('sunitname') + '</option>')
        
        // after click on addTocartBtn show primary price initially
        $("#mrp").val($(this).data('punitrate'))
        $("#amount").val($(this).data('punitrate'))
        selectProductId = $(this).attr('id')
        $("#closeBtn1").show()
        $("#closeBtn2").hide()
        $("#saveBtn").show()
        $("#updateBtn").hide()
        $("#productListModal").modal("hide")
        $("#productModal").modal("show")        
    })

    $("#addToCartForm").on('change', '#_unit', function(event) {
        event.preventDefault()
        let mrp = $(this).find(':selected').data('mrp')
        $("#mrp").val(mrp)
        amountCalculation()
    })

    $("#addToCartForm").on('keyup', '#discount_percentage', function(event) {
        event.preventDefault()
        let mrp = $("#mrp").val() 
        let percent = $("#discount_percentage").val() 
        let discount = (mrp*percent)/100;
        $("#discount").val(parseFloat(discount).toFixed(2));
    })

    $("#addToCartForm").on('keyup', '#discount', function(event) {
        event.preventDefault()
        let mrp = $("#mrp").val() 
        let discount = $("#discount").val() 
        let percent = 100 - (((mrp - discount)/mrp)*100);
        $("#discount_percentage").val(parseFloat(percent).toFixed(2));
    })

    $("#addToCartForm").on('keyup', '#mrp,#discount_percentage,#discount,#qty', function(event) {
        event.preventDefault()
        amountCalculation()
    })

    $("#addToCartForm").on('click', '.stepper-up', function(event) {
        event.preventDefault()
        $("#qty").val(+$(this).prev().val() + 1)
        amountCalculation()
    })

    $("#addToCartForm").on('click', '.stepper-down', function(event) {
        event.preventDefault()
        if ($(this).next().val() > 1) {
            $("#qty").val(+$(this).next().val() - 1)
            amountCalculation()
        }
    })

    $("#received").on('keyup',function(){
        if($("#received").val() != ''){
            totalCalculation()
        }    
    })
    $("#delivery_charges").on('keyup',function(){
        if($("#delivery_charges").val() != ''){
            totalCalculation()
        }    
    })
    $("#round_off").on('keyup',function(){
        if($("#round_off").val() != ''){
            totalCalculation()
        }  
    })
    $("#last_discount").on('keyup',function(){
        if($("#last_discount").val() != ''){
            totalCalculation()
        }  
    })
    $("#gst_amount").on('keyup',function(){
        if($("#gst_amount").val() != ''){
            totalCalculation()
        }
    })

    $("#addToCartForm").on('click', '#closeBtn1', function(event) {
        event.preventDefault()
        $("#_unit").empty().append()
        $("#addToCartForm")[0].reset()
        $("#productModal").modal("hide")
        $("#productListModal").modal("show")
    })

    $("#addToCartForm").on('click', '#closeBtn2', function(event) {
        event.preventDefault()
        $("#_unit").empty().append()
        $("#addToCartForm")[0].reset()
        $("#productModal").modal("hide")
    })

    var selectProductInfo = {}
    var allProductsInfo = [];

    $("#addToCartForm").on('click', '#saveBtn', function(event) {
        event.preventDefault()
        $("#customer_id").val(localStorage.getItem('customerID'))
        selectProductInfo = {
            customerId: customerId,
            selectProductId: selectProductId,
            unitId: $("#_unit").find(':selected').data('uid'),
            unitName: $("#_unit").find(':selected').data('uname'),
            qty: $("#qty").val(),
            mrp: $("#mrp").val(),
            discount_percentage: $("#discount_percentage").val(),
            discount: $("#discount").val(),
            amount: $("#amount").val(),
        }        
        allProductsInfo.push(selectProductInfo);
        $("#addCartItemBtn").attr('disabled', false)
        reArragneProductlist()
        totalCalculation()
        $("#_unit").empty().append()
        $("#addToCartForm")[0].reset()    
        $("#productModal").modal("hide")
        $("#productListModal").modal("show")    
    })

    function reArragneProductlist(argument) {
        var addedProduct = []
        var notAddedProduct = []
        var elemProducts = products
        var x = []
        var j = 0
        for (let count = 0; count < allProductsInfo.length; count++) {
            for (let i = 0; i < products.length; i++) {
                if (products[i].product_id == allProductsInfo[count].selectProductId) {
                    addedProduct[count] = products[i]
                }
            }
            elemProducts = elemProducts.filter(elem => {
                return elem.product_id != allProductsInfo[count].selectProductId;
            })
        }

        $("#product_table > tbody").empty();
        products = []
        products = $.merge(addedProduct, elemProducts)
        productTable()
        changeButtonAttrOfSelectedproducts()
        showAddedProductsOnCart()
    }

    function changeButtonAttrOfSelectedproducts(argument) {
        for (var count = 0; count < allProductsInfo.length; count++) {
            $("#" + allProductsInfo[count].selectProductId).removeClass('btn-primary')
            $("#" + allProductsInfo[count].selectProductId).addClass('btn-secondary')
            $("#" + allProductsInfo[count].selectProductId).attr('disabled', true)
            $("#" + allProductsInfo[count].selectProductId).children().removeClass("bi-plus-lg");
            $("#" + allProductsInfo[count].selectProductId).children().addClass("bi-check");
            $("#" + allProductsInfo[count].selectProductId).removeClass("btn-danger");
            $("#" + allProductsInfo[count].selectProductId).addClass("btn-success");
        }        
    }

    function showAddedProductsOnCart() {
        $("#order_table > tbody").empty()
        for(let count=0; count < allProductsInfo.length; count++){
            let thisProduct = products.filter(function(a){
                return a.product_id == allProductsInfo[count].selectProductId
            })   
            let disc,discPCT
            if(allProductsInfo[count].discount > 0){
                discPCT = '<td class="text-danger">'+parseFloat(allProductsInfo[count].discount_percentage).toFixed(2) +' %</td>'
                disc = '<td class="inr-sign text-danger">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(allProductsInfo[count].discount) +'</td>'
            }   
            else{
                discPCT = '<td class="">'+parseFloat(allProductsInfo[count].discount_percentage).toFixed(2) +' %</td>'
                disc = '<td class="inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(allProductsInfo[count].discount) +'</td>'
            }
            $("#order_table tbody").append('<tr>'+
                '<td><div class="form-links">'+
                        '<div><small class="text-sm" style="margin-right: 150px;">'+thisProduct[0].product_name+' - '+thisProduct[0].brand_name+'</small></div>'+
                        '<div><a href="javascript:void(0)"  data-bs-toggle="offcanvas" data-bs-target="#actionModal" class="cart-item-edit-menu" '+
                        'data-id="'+allProductsInfo[count].selectProductId+'" data-pname="'+thisProduct[0].product_name+'" data-bname="'+thisProduct[0].brand_name+'">'+
                        '<i class="bi bi-menu-up" class="text-primary" style="height:20px; width: 20px;"></i></a></div>'+
                    '</div></td>'+
                '<td>'+allProductsInfo[count].qty+'('+allProductsInfo[count].unitName+')</td>'+
                '<td class="inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(allProductsInfo[count].mrp) +'</td>'+
                discPCT+
                disc+
                '<td class="inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(allProductsInfo[count].amount) +'</td>'+
                '</tr>')
        }
    }          

    $(document).on('click',".cart-item-edit-menu",function(event){
        event.preventDefault()
        $('#actiontitle').text($(this).data('pname')+' - '+$(this).data('bname'))
        $('.offcanvas-body').html('<ul class="action-button-list">'+
                                    '<li>'+
                                        '<a href="javascript:void(0)" class="btn btn-list editItem" data-bs-dismiss="offcanvas" data-id="'+$(this).data('id')+'">'+
                                            '<span class="pb-2 pt-2" style="padding-left: 47%"><i class="bi bi-pencil-square"></i>Edit</span>'+
                                        '</a>'+
                                    '</li>'+
                                    '<li>'+
                                        '<a href="javascript:void(0)" class="btn btn-list text-danger delItem" data-bs-dismiss="offcanvas" data-id="'+$(this).data('id')+'">'+
                                            '<span class="pb-2" style="padding-left: 44%"><i class="bi bi-trash"></i>Remove</span>'+
                                        '</a>'+
                                    '</li>'+                                 
                                '</ul>')
    })

    $(document).on('click','.editItem',function(event){
        event.preventDefault()
        let id = $(this).data('id')
        selectProductId = id
        let primary_mrp = 0 , secondary_mrp = 0
        for(let count=0; count < allProductsInfo.length; count++){
            if(id == allProductsInfo[count].selectProductId){
                let thisProduct = products.filter(function(a){
                    return a.product_id == allProductsInfo[count].selectProductId
                }) 
                if(customerType == 1){
                    primary_mrp = thisProduct[0].r_pri_unit_rate
                    secondary_mrp = thisProduct[0].r_sec_unit_rate
                }
                if(customerType == 2){
                    primary_mrp = thisProduct[0].d_pri_unit_rate
                    secondary_mrp = thisProduct[0].d_sec_unit_rate
                }
                $("#_unit").empty().append()  
                if(thisProduct[0].primary_unit_id == allProductsInfo[count].unitId){
                    $("#_unit").append('<option class="text-capitalize" data-uid="' + thisProduct[0].primary_unit_id + '" data-uname="' + thisProduct[0].primary_unit_name + '" data-mrp="' + primary_mrp + '">' + thisProduct[0].primary_unit_name + '</option>' +
                           '<option class="text-capitalize" data-uid="' + thisProduct[0].secondary_unit_id + '" data-uname="' + thisProduct[0].secondary_unit_name + '" data-mrp="' + secondary_mrp + '">' + thisProduct[0].secondary_unit_name + '</option>')
                }
                if(thisProduct[0].secondary_unit_id == allProductsInfo[count].unitId){
                    $("#_unit").append('<option class="text-capitalize" data-uid="' + thisProduct[0].secondary_unit_id + '" data-uname="' + thisProduct[0].secondary_unit_name + '" data-mrp="' + secondary_mrp + '">' + thisProduct[0].secondary_unit_name + '</option>'+
                                        '<option class="text-capitalize" data-uid="' + thisProduct[0].primary_unit_id + '" data-uname="' + thisProduct[0].primary_unit_name + '" data-mrp="' + primary_mrp + '">' + thisProduct[0].primary_unit_name + '</option>')
                }             
                $("#mrp").val(allProductsInfo[count].mrp)
                $("#qty").val(allProductsInfo[count].qty)
                $("#discount_percentage").val(allProductsInfo[count].discount_percentage)
                $("#discount").val(allProductsInfo[count].discount)
                $("#amount").val(allProductsInfo[count].amount)
                $('.modal-title').text(thisProduct[0].product_name+' - '+thisProduct[0].brand_name)
                
            }
            $("#closeBtn1").hide()
            $("#closeBtn2").show()
            $("#saveBtn").hide()
            $("#updateBtn").show()
            $("#productModal").modal("show")  
        }
    })

    $("#addToCartForm").on('click', '#updateBtn', function(event) {
        event.preventDefault()
        $("#customer_id").val(localStorage.getItem('customerID'))
        for (var i = 0; i < allProductsInfo.length; i++) {
            if(allProductsInfo[i].selectProductId == selectProductId){
                allProductsInfo[i].customerId = customerId
                allProductsInfo[i].selectProductId = selectProductId
                allProductsInfo[i].unitId = $("#_unit").find(':selected').data('uid')
                allProductsInfo[i].unitName = $("#_unit").find(':selected').data('uname')
                allProductsInfo[i].qty = $("#qty").val()
                allProductsInfo[i].mrp = $("#mrp").val()
                allProductsInfo[i].discount_percentage = $("#discount_percentage").val()
                allProductsInfo[i].discount = $("#discount").val()
                allProductsInfo[i].amount = $("#amount").val()
            }
        }
        showAddedProductsOnCart()
        $("#addCartItemBtn").attr('disabled', false)
        totalCalculation()
        $("#_unit").empty().append()
        $("#productModal").modal("hide")
        $("#addToCartForm")[0].reset()
    })

    $(document).on('click','.delItem',function(event){
        event.preventDefault()
        let id = $(this).data('id')
        let thisProduct = products.filter(function(a){
            return a.product_id == id
        })        
        $('.modal-title').text(thisProduct[0].product_name+' - '+thisProduct[0].brand_name)
        $("#delConfirmBtn").val(id)
        $("#delModal").modal('show')
    })

    $(document).on('click','#delConfirmBtn',function(event){
        event.preventDefault()
        let id = $(this).val()
        allProductsInfo = allProductsInfo.filter(function(elem){
            return elem.selectProductId != id
        })         
        reArragneProductlist()
        totalCalculation()
        $("#delModal").modal("hide")
    })
    function amountCalculation() {
        let mrp = $("#mrp").val()
        let discount = $("#discount").val()
        let qty = $("#qty").val()
        let amount = qty * (parseFloat(mrp) - parseFloat(discount))
        $("#amount").val(parseFloat(amount).toFixed(2))
    }

    totalCalculation()
    function totalCalculation() {
        var subTotal = 0;
        var total = 0;
        var received = $("#received").val()
        var roundOff = $("#round_off").val()
        var lastDisc = $("#last_discount").val()
        var deliveryCharges = $("#delivery_charges").val()
        var gstAmount = $("#gst_amount").val()
        var itemCount = 0;
        var itemId = 0;
        for (var i = 0; i < allProductsInfo.length; i++) {
            subTotal = parseFloat(subTotal) + parseFloat(allProductsInfo[i].amount);
            if (allProductsInfo[i].selectProductId != itemId) {
                itemCount++;
                itemId = allProductsInfo[i].selectProductId;
            }
        }
        total = parseFloat(subTotal) + parseFloat(gstAmount);   
        total = parseFloat(total) + parseFloat(deliveryCharges);  
        total = parseFloat(total) - parseFloat(roundOff);    
        total = parseFloat(total) - parseFloat(lastDisc);    
        var balance = parseFloat(total) - parseFloat(received);
        balance = parseFloat(balance) + parseFloat(prevBalance)

        inoviceBottomForm = {            
            round_off: $("#round_off").val(),
            last_discount: $("#last_discount").val(),
            delivery_charges: $("#delivery_charges").val(),
            gst_amount: $("#gst_amount").val(),
            received: $("#received").val(),
            prev_balance : prevBalance,
            total : total,
            balance : balance,
        }
        $(".total").html(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(total))        
        $(".balance").html(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(balance))  
        $("#itemCount").html(itemCount + " Item(s) <span style='font-size: 30px;font-weight: normal;'>|</span>")
    }

    var orderDate
    $(document).on('click', '#addCartItemBtn', function(event) {
        event.preventDefault()
        $("#productModal").modal("hide")
        $("#productListModal").modal("hide")
        $("#confirmModal .modal-title").text('Confirm Order')
        $("#confirmModal").modal('show') 
    })
    
    $(document).on('click',"#order_date",(e)=>{
        e.preventDefault()
        $("#confirmModal").modal('hide') 
    })
    duDatepicker('#order_date', {
        format: 'dd-mm-yyyy',cancelBtn: true,minDate:moment("2022-01-01"),maxDate:'today',
        // disabledDays: ['Sat', 'Sun'],
        events: {
            dateChanged: function (res) { 
                orderDate = new Date(res._date).getFullYear()+'-'+(new Date(res._date).getMonth()+1)+'-'+new Date(res._date).getDate();
                $("#confirmModal #order_date").val(res.date)
                $("#confirmModal").modal('show')  
            }
        }
    })
    var confirmModaldata ={}
    $(document).on('click', '#orderConfirmBtn', function(event) {
        event.preventDefault()
        $("#loader").show()
        confirmModaldata = {
            order_date : $("#order_date").val(),
            payment_type : $("#payment_type").val(),
            remarks : $("#remarks").val(),
        }
        $("#confirmModal .text-danger").html('')
        saveCartItem(confirmModaldata)
    })

    function saveCartItem() {
        $.ajax({
            type: 'POST',
            url: base_url + "api/sale/order/create",
            data: { confirmModaldata:confirmModaldata, allProductsInfo: allProductsInfo, inoviceBottomForm:inoviceBottomForm },
            dataType: 'json',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                'Accept': 'application/json',
                "Authorization": "Bearer " + access_token
            },
            success: function(response) {
                $("#loader").hide()
                if(response.errors){
                    if(response.errors.order_date){
                        $("#order_date_error").text(response.errors.order_date[0])
                    }
                    if(response.errors.payment_type){
                        $("#payment_type_error").text(response.errors.payment_type[0])
                    }
                    if(response.errors.message){
                        $("#confirmModal").modal('hide') 
                        errortoast(response.errors.message[0])
                    }
                }
                if(response.success){
                    $('#successModal .modal-title').text(response.success)
                    $("#confirmModal").modal('hide') 
                    $("#successModal").modal('show')
                }

            }, // success end
            error: function(badRes) {
                $("#loader").hide()
                errortoast(badRes.statusText)
                if(navigator.onLine == false){
                    saveCartItem();
                }
                if(badRes.status > 200){
                    saveCartItem();
                }
                if (badRes.status == 401) {
                    localStorage.removeItem('access_token');
                    if(localStorage.getItem('email')){
                        window.location.href = "auth/unlock.html"
                    }
                    else{
                        window.location.href = "auth/login.html"
                    }

                }
            }, //ajax error end

        }); //Ajax End
    }

    /*--------- Product Search related function here ------------*/
    $(document).on("keyup", "#product_search", function() {
        var value = $(this).val().toLowerCase();
        searchFunction(value)
    });

    $(document).on('click', '#headerCloseBtn', function(event) {
        event.preventDefault()
        $("#product_search").val('')
        $("#product_search").attr('placeholder', 'Search product here...')
        $("#search").removeClass('show')
        var value = ''
        searchFunction(value)
    })

    function searchFunction(value) {
        $("#product_table tbody tr").filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });
    }
    /*--------- Product Search related function here ------------*/
})
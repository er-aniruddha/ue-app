$(document).ready(function() {
    $("#header").load('layouts/header.html')
    $("#sidebar").load('layouts/sidebar.html')   
    $("#footer").load('layouts/footer.html')   
    var access_token = localStorage.getItem('access_token')     
    var customerId = localStorage.getItem('customerID')            
    var allTableData, customer

    var startDate = moment().subtract(1,'year').format("YYYY-MM-DD")
    var endDate = moment().format("YYYY-MM-DD")
    duDatepicker('#start_date', {
        format: 'yyyy-mm-dd',cancelBtn: true,minDate:moment("2021-01-01"),maxDate:'today',
        // disabledDays: ['Sat', 'Sun'],
        events: {
            dateChanged: function (res) {            
                startDate = res.date                
                trnxDataTable.destroy();
                load_bill_table(startDate,endDate)
                loadInitial()
            }
        }
    })
    duDatepicker('#end_date', {
        format: 'yyyy-mm-dd',cancelBtn: true,minDate:moment("2021-01-01"),maxDate:'today',
        // disabledDays: ['Sat', 'Sun'],
        events: {
            dateChanged: function (res) {            
                endDate = res.date
                trnxDataTable.destroy();
                load_bill_table(startDate,endDate)
                loadInitial()
            }
        }
    })
    function loadInitial(argument) {
        $('#loader').show();
        $.ajax({
            method: "GET",
            url: base_url+"api/customer/profile/"+customerId,
            dataType: "json",
            data:{startDate:startDate,endDate:endDate},
            contentType: false,
            cache: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                'Accept': 'application/json',
                "Authorization": "Bearer " + access_token
            },
            success: function(response) {  
                $("#start_date").val(startDate)
                $("#end_date").val(endDate)
                allTableData = response.allTableData
                customer = response.customer
                $("#profilName").html(customer.f_name+' '+customer.s_name+' ('+customer.shop_name+')')
                $("#locality").html(customer.locality)
                $("#phone_1").html(customer.phone_1)
                if(customer.phone_2){
                    $("#phone_2").html(customer.phone_2)  
                }
                else{
                    $("#phone_2").html('NA')  
                }                        
                if(customer.balance > 0){
                    $("#balance").text(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(customer.balance))
                }  
                else{
                    $("#balance").text(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(customer.balance))
                }           
                localStorage.setItem('prevBalance',customer.balance)
                $("#sales").text(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(response.saleTotal))
                $("#crNote").text(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(response.crNoteTotal))
                $("#discount").text(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(response.discTotal))
                $("#grandSale").text(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(response.grandTotal))
                $("#schemePurchase").text(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(response.purchaseAmount))
                $("#schemeDisc").text(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(response.discountedAmount))
                var ouDue = customer.balance - response.discountedAmount
                $("#ouDue").text(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(ouDue))
                $("#appHeader").addClass('is-active')
                $("#appHeader").removeClass('scrolled')
                $(".pageTitle").text('Customer Profile')
                $("#searchBtn").remove()
                $('#loader').hide();
            }, //success end
            error: function(badRes,t) {
                // errortoast(badRes.statusText)
                if(navigator.onLine == false){
                    loadInitial()
                }
                if (badRes.status > 200) {
                    loadInitial()                            
                }
                if (badRes.status == 401) {
                    localStorage.removeItem('access_token');
                    if(localStorage.getItem('email')){
                        window.location.href = "auth/unlock.html"
                    }
                    else{
                        window.location.href = "auth/login.html"
                    }
                    
                }
            }, //ajax error end
        }) //ajax end
    }
    loadInitial()
    load_bill_table(startDate,endDate)            
    $(document).on("click","p.call-number", function() {
        let number = $(this).data('number')
       window.location.href = "tel:+91"+number
    }); 
    /*-------- Transaction DataTable Start Here --------*/  
    function load_bill_table(startDate,endDate){
        trnxDataTable = $("#trnx_table").DataTable({
            "bPaginate": true,
            "bLengthChange": false,
            "bInfo": false,
            "searching": false,
            processing: true,
            responsive: true,
            serverSide: true,
            "order": [[ 0, "desc" ]],
            ajax: {
                url:  base_url+"api/customer/data_table/transaction/"+customerId,
                dataType: "json",
                data:{ startDate: startDate, endDate: endDate},
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                    'Accept': 'application/json',
                    "Authorization": "Bearer " + access_token
                },
            },         
            success:function(){
                
            },
            columns: [{
                    data: "order_date",
                    name: "order_date",
                    render: function(data, type, full, meta) {
                        return '<span class="text-sm text-capitalize">'+moment(data).format('DD-MM-YYYY')+'</span>'
                    },      
                }, {
                    data: "delivery_date",
                    name: "delivery_date",
                    render: function(data, type, full, meta) {
                        if(data){
                            return '<span class="text-sm text-capitalize">'+moment(data).format('DD-MM-YYYY')+'</span>'
                        }
                        if(!data){
                            return '<span class="text-sm item-badge badge text-uppercase bg-warning">Not Deliverd</span>';     
                        }
                    },      
                }, {
                    data: "trnxid",
                    name: "trnxid",
                },{
                    data: "payment_type",
                    name: "payment_type",
                    render: function(data){
                        if(data == 1){
                            return '<span class="text-sm text-capitalize">Cash</span>'
                        }
                        if(data == 2){
                            return '<span class="text-sm text-capitalize">Online</span>'
                        }
                        if(data == 3){
                            return '<span class="text-sm text-capitalize">Cheque</span>'
                        }
                        if(data == 4){
                            return '<span class="text-sm text-capitalize">Not Paid</span>'
                        }
                        if(data == 5){
                            return '<span class="text-sm text-capitalize">On Bill</span>'
                        }
                    }
                },{
                    data: "total",
                    name: "total",
                    render: function(data){
                        return '<span class="text-sm inr-sign"> '+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
                    }
                },{
                    data: "prev_balance",
                    name: "prev_balance",
                    render: function(data){
                        return '<span class="text-sm inr-sign"> '+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
                    }
                },{
                    data: "received",
                    name: "received",
                    render: function(data){
                        return '<span class="text-sm inr-sign"> '+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
                    }
                }, {
                    data: "balance",
                    name: "balance",
                    render: function(data){
                        return '<span class="text-sm inr-sign"> '+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
                    }
                },{
                    data: "payment_status",
                    name: "payment_status",
                    render: function(data){
                        if(data == 0){
                            return '<span class="text-sm text-capitalize text-danger">Unpaid</span>'
                        }
                        if(data == 1){
                            return '<span class="text-sm text-capitalize text-warning">Partial</span>'
                        }
                        if(data == 2){
                            return '<span class="text-sm text-capitalize text-success">Paid</span>'
                        }
                        // for PaymentIN 
                        if(!data){
                            return '<span class="text-sm text-capitalize text-success">Paid</span>'
                        }
                    }
                },{
                    data: "status",
                    name: "status",
                }],

        }); 
        
    }      
    /*------ Transaction dataTable end here ------*/
 
    var pdfId;
    /*------- View Start Here -------------*/
    $("#trnx_table tbody").on('click','tr td:not(:last-child)',function() {       
        let saletrnxId = trnxDataTable.row( this ).data()['sale_trnx_id']
        let crtrnxId = trnxDataTable.row( this ).data()['cr_trnx_id']
        let payintrnxid = trnxDataTable.row( this ).data()['payment_in_trnx_id']
        let sale_status = trnxDataTable.row( this ).data()['sale_status']
        let cr_status = trnxDataTable.row( this ).data()['cr_status']
        $('.inv-addedrow').remove();  
        if(saletrnxId){
            $('#inv-table').show();
            if(sale_status == 1){
                $("#invTitle").text('Invoice')
                $('#viewModal .modal-title').text("Sale Details: #INV-"+saletrnxId);
                $('.invoice-id').text("#INV-"+saletrnxId)
                pdfId = "INV_"+saletrnxId
            }
            else{
                $("#invTitle").text('Proforma Invoice')
                $('#viewModal .modal-title').text("Sale Details: #OD-"+saletrnxId);
                $('.invoice-id').text("#OD-"+saletrnxId)
                pdfId = "OD_"+saletrnxId
            }
            viewSaleDetails(saletrnxId)
        }
        if(crtrnxId){
            $('#inv-table').show();
            if(cr_status == 1){
                $("#invTitle").text('Credit Note')
                $('#viewModal .modal-title').text("Credit Note Details: #CRN-"+crtrnxId);
                $('.invoice-id').text("#CRN-"+crtrnxId)
                pdfId = "CRN_"+crtrnxId
            }
            else{
                $("#invTitle").text('Porose Credit Note')
                $('#viewModal .modal-title').text("Credit Note Details: #CRN-OD-"+crtrnxId);
                $('.invoice-id').text("#CRN-OD-"+crtrnxId)
                pdfId = "CRN_OD_"+crtrnxId
            }
            viewCreditNoteDetails(crtrnxId)         
        }
        if(payintrnxid){            
            $('#inv-table').hide();
            $("#invTitle").text('Payment Receipt')
            $("#viewModal .modal-header").addClass('bg-white')
            $('#viewModal .modal-title').text("Payment Details: #PAY-IN-"+payintrnxid);
            $('.invoice-id').text("#PAY-IN-"+payintrnxid)   
            $("#generateImage,#generatePdf").show()
            viewPaymentInDetails(payintrnxid)
            pdfId = "PAY_IN_"+payintrnxid
        }
    })
    
    /*------- View End Here -------------*/

    function viewSaleDetails(trnxId) {
        var rowCount = 0
        for (var count = 0; count < allTableData.length; count++){
            if(trnxId == allTableData[count].sale_trnx_id){
                let disc,discPCT
                if(allTableData[count].sale_discount > 0){
                    discPCT = '<td class="text-danger">'+parseFloat(allTableData[count].sale_discount_percentage).toFixed(2)+' %</td>'
                    disc = '<td class="inr-sign text-danger">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(allTableData[count].sale_discount)+'</td>'
                }
                else{
                    discPCT = '<td class="">'+parseFloat(allTableData[count].sale_discount_percentage).toFixed(2)+' %</td>'
                    disc = '<td class="inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(allTableData[count].sale_discount)+'</td>'
                }
                rowCount++
                if(rowCount%17 == 0 && rowCount != 0){
                   $("#inv-table tbody").append('<tr class="inv-addedrow">'+
                                '<td><small>'+allTableData[count].product_name+' - '+allTableData[count].brand_name+ '</small></td>'+
                                '<td>'+allTableData[count].sale_qty+' ('+allTableData[count].unit_code+')</td>'+
                                '<td class="inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(allTableData[count].sale_unit_price)+'</td>'+
                                discPCT+
                                disc+
                                '<td class="inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(allTableData[count].sale_amount)+'</td>'+                                        
                            '</tr>')
                }  
                else{
                    $("#inv-table tbody").append('<tr class="inv-addedrow">'+
                                '<td><small>'+allTableData[count].product_name+' - '+allTableData[count].brand_name+ '</small></td>'+
                                '<td>'+allTableData[count].sale_qty+' ('+allTableData[count].unit_code+')</td>'+
                                '<td class="inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(allTableData[count].sale_unit_price)+'</td>'+
                                discPCT+
                                disc+
                                '<td class="inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(allTableData[count].sale_amount)+'</td>'+                                        
                            '</tr>')
                }
                
                $("#viewModal").modal('show')
                $('.invoice-to').html('<h4 class="text-capitalize"><i class="bi bi-shop"></i>&nbsp;'+allTableData[count].shop_name+'</h4>'+
                                    '<h3 class="text-capitalize">'+allTableData[count].f_name+' '+allTableData[count].s_name+'</h3>'+
                                    '<p class="text-capitalize"><i class="bi bi-telephone"></i>&nbsp;'+allTableData[count].phone_1+'</p>'+
                                    '<p class="text-capitalize"><i class="bi bi-geo-alt"></i>&nbsp;'+allTableData[count].locality+'</p>')
                $(".invoice-total").html('<ul class="listview transparent simple-listview">'+
                                '<li>Round Off <span class="hightext inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(allTableData[count].sale_round_off)+'</span></li>'+
                                '<li>Other Discount <span class="hightext inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(allTableData[count].sale_last_discount)+'</span></li>'+
                                '<li>Delivery Charges <span class="hightext inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(allTableData[count].sale_delivery_charges)+'</span></li>'+
                                '<li>Tax <span class="hightext inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(allTableData[count].sale_gst_amount)+'</span></li>'+
                                '<li>Total<span class="totaltext text-primary inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(allTableData[count].sale_total)+'</span></li>'+
                                '<li>Prev. Balance<span class="hightext text-dark inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(allTableData[count].sale_prev_balance) +'</span></li>'+
                                '<li>Received &#92; Paid <span class="hightext inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(allTableData[count].sale_received) +'</span></li>'+
                                '<li>Balance <span class="hightext text-danger inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(allTableData[count].sale_balance) +'</span></li>'+
                           '</ul>')

                // $("#inv-table tbody").append('<tr class="inv-addedrow">'+
                //                 '<td><small>'+allTableData[count].product_name+' - '+allTableData[count].brand_name+ '</small></td>'+
                //                 '<td>'+allTableData[count].sale_qty+' ('+allTableData[count].unit_code+')</td>'+
                //                 '<td class="inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(allTableData[count].sale_unit_price)+'</td>'+
                //                 disc+
                //                 '<td class="inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(allTableData[count].sale_amount)+'</td>'+                                        
                //             '</tr>')

                $(".order-date").html('<p>Order Date : '+moment(allTableData[count].sale_order_date, 'YYYY-MM-DD').format("DD-MM-YYYY")+'</p>')

                if(allTableData[count].sale_delivery_date){
                    $(".delivery_date").html('<p>Delivery Date : '+moment(allTableData[count].sale_delivery_date, 'YYYY-MM-DD').format("DD-MM-YYYY")+'</p>')
                }
                else{
                    $(".delivery_date").html('<p>Delivery Date : NOT DELIVERED</p>')
                }
                
                if(allTableData[count].sale_payment_type == 1){
                    $(".payment-type").html('<p>Payment Type : Cash</p>')
                }
                if(allTableData[count].sale_payment_type == 2){
                    $(".payment-type").html('<p>Payment Type : Online</p>')
                }
                if(allTableData[count].sale_payment_type == 3){
                    $(".payment-type").html('<p>Payment Type : Cheque</p>')
                } 
                if(allTableData[count].sale_payment_type == 4){
                    $(".payment-type").html('<p>Payment Type : No Payment</p>')
                } 
                              
            }            
        }        
    }
    function viewCreditNoteDetails(trnxId) {
        for (var count = 0; count < allTableData.length; count++){
            if(trnxId == allTableData[count].cr_trnx_id){
                $("#viewModal").modal('show')
                $('.invoice-to').html('<h4 class="text-capitalize"><i class="bi bi-shop"></i>&nbsp;'+allTableData[count].shop_name+'</h4>'+
                                    '<h3 class="text-capitalize">'+allTableData[count].f_name+' '+allTableData[count].s_name+'</h3>'+
                                    '<p class="text-capitalize"><i class="bi bi-telephone"></i>&nbsp;'+allTableData[count].phone_1+'</p>'+
                                    '<p class="text-capitalize"><i class="bi bi-geo-alt"></i>&nbsp;'+allTableData[count].locality+'</p>')
                $(".invoice-total").html('<ul class="listview transparent simple-listview">'+
                                '<li>Round Off <span class="hightext inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(allTableData[count].cr_round_off)+'</span></li>'+
                                '<li>Delivery Charges <span class="hightext inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(allTableData[count].cr_delivery_charges)+'</span></li>'+
                                '<li>Tax <span class="hightext inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(allTableData[count].cr_gst_amount)+'</span></li>'+
                                '<li>Total<span class="totaltext text-primary inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(allTableData[count].cr_total)+'</span></li>'+
                                '<li>Prev. Balance<span class="hightext text-dark inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(allTableData[count].cr_prev_balance) +'</span></li>'+
                                '<li>Received &#92; Paid <span class="hightext inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(allTableData[count].cr_paid) +'</span></li>'+
                                '<li>Balance <span class="hightext text-danger inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(allTableData[count].cr_balance) +'</span></li>'+
                           '</ul>')

                $("#inv-table").append('<tr class="inv-addedrow">'+
                                '<td>'+allTableData[count].product_name+' - '+allTableData[count].brand_name+ '</td>'+
                                '<td>'+allTableData[count].cr_qty+'('+allTableData[count].unit_code+')</td>'+
                                '<td class="inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(allTableData[count].cr_unit_price)+'</td>'+
                                '<td class="inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(0)+'</td>'+
                                '<td class="inr-sign">0 %</td>'+
                                '<td class="inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(allTableData[count].cr_amount)+'</td>'+                                        
                            '</tr>')
                $(".order-date").html('<p>Order Date : '+moment(allTableData[count].cr_order_date, 'YYYY-MM-DD').format("DD-MM-YYYY")+'</p>')

                if(allTableData[count].cr_delivery_date){
                    $(".delivery_date").html('<p>Delivery Date : '+moment(allTableData[count].cr_delivery_date, 'YYYY-MM-DD').format("DD-MM-YYYY")+'</p>')
                }
                else{
                    $(".delivery_date").html('<p>Delivery Date : NOT DELIVERED</p>')
                }
                
                if(allTableData[count].cr_payment_type == 1){
                    $(".payment-type").html('<p>Payment Type : Cash</p>')
                }
                if(allTableData[count].cr_payment_type == 2){
                    $(".payment-type").html('<p>Payment Type : Online</p>')
                }
                if(allTableData[count].cr_payment_type == 3){
                    $(".payment-type").html('<p>Payment Type : Cheque</p>')
                } 
                if(allTableData[count].cr_payment_type == 4){
                    $(".payment-type").html('<p>Payment Type : No Payment</p>')
                } 
                
            }
        }
    }

    function viewPaymentInDetails(trnxId){
        for (var count = 0; count < allTableData.length; count++){
            if(trnxId == allTableData[count].payment_in_trnx_id){
                $("#viewModal").modal('show')
                $('.invoice-to').html('<h4 class="text-capitalize"><i class="bi bi-shop"></i>&nbsp;'+allTableData[count].shop_name+'</h4>'+
                                    '<h3 class="text-capitalize">'+allTableData[count].f_name+' '+allTableData[count].s_name+'</h3>'+
                                    '<p class="text-capitalize"><i class="bi bi-telephone"></i>&nbsp;'+allTableData[count].phone_1+'</p>'+
                                    '<p class="text-capitalize"><i class="bi bi-geo-alt"></i>&nbsp;'+allTableData[count].locality+'</p>')
                $(".invoice-total").html('<ul class="listview transparent simple-listview">'+
                                '<li>Prev. Balance<span class="hightext text-dark inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(allTableData[count].prev_balance)+'</span></li>'+
                                '<li>Received &#92; Paid <span class="hightext inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(allTableData[count].received)+'</span></li>'+
                                '<li>Balance <span class="hightext text-danger inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(allTableData[count].balance)+'</span></li>'+
                                '<li>Remarks <span class="hightext text-danger">'+allTableData[count].remarks+'</span></li>'+
                           '</ul>')

                $(".order-date").html('<p>Order Date : '+moment(allTableData[count].date, 'YYYY-MM-DD').format("DD-MM-YYYY")+'</p>')

                if(allTableData[count].payment_type == 1){
                    $(".payment-type").html('<p>Payment Type : Cash</p>')
                }
                else if(allTableData[count].payment_type == 2){
                    $(".payment-type").html('<p>Payment Type : Online</p>')
                }
                else{
                    $(".payment-type").html('<p>Payment Type : Cheque</p>')
                } 
            }
        }        
       
    }

    $(document).on('click',"#paymentIn",function(event){
        event.preventDefault()
        $("#paymentInModal").modal('show')
        $("#paymentInModal .modal-title").text('Payment In')
        let prev_balance = localStorage.getItem('prevBalance') // this localStorage is from after initialize customer variable
        $('#prev_balance').val(prev_balance)
        $('#pay_customer_id').val(customerId)
    })
    
    $(document).on('click',"#date",(e)=>{
        e.preventDefault()
        $("#paymentInModal").modal('hide') 
    })

    duDatepicker('#date', {
        format: 'dd-mm-yyyy',cancelBtn: true,minDate:moment("2022-01-01"),maxDate:'today',
        // disabledDays: ['Sat', 'Sun'],
        events: {
            dateChanged: function (res) {                
                $("#paymentInModal #date").val(res.date)
                $("#paymentInModal").modal('show')  
            }
        }
    })

    $(document).on('click',"#savePaymentInBtn",function(event){
        event.preventDefault()
        $('#loader').add();
        savePayment()
    })

    function savePayment() {
        $("#payment-form .text-danger").html("") 
        var formData = new FormData($('#payment-form')[0]);
        $.ajax({
            method: 'POST',
            url: base_url+'api/payment-in/create',
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: formData,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                'Accept': 'application/json',
                "Authorization": "Bearer " + access_token
            },
            success: function (response) {
                if(response.errors){
                    if(response.errors.date){
                        $("#date_error").text(response.errors.date[0])
                    }
                    if(response.errors.received){
                        $("#received_error").text(response.errors.received[0])
                    }
                    if(response.errors.balance){
                        $(".balance_error").text(response.errors.balance[0])
                    } 
                    if(response.errors.payment_type){
                        $("#payment_type_error").text(response.errors.payment_type[0])
                    }                                    
                }
                //on success
                else{
                    $('#trnx_table').DataTable().ajax.reload();                
                    $("#payment-form")[0].reset()
                    $('input').attr('value' , '')   
                    notification(response.message)    
                    loadInitial()                      
                    let customer = response.customer
                    localStorage.setItem('prevBalance',customer.balance)
                    $("#balance").empty();
                    if(customer.balance > 0){
                        $("#balance").text(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(customer.balance))
                    }  
                    else{
                        $("#balance").text(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(customer.balance))
                    }
                    $("#paymentInModal").modal('hide')
                }                   
                $('#loader').hide();     
            },
            error: function(badRes,t) {
                $('#loader').hide();   
                errortoast(badRes.statusText)
                if(navigator.onLine == false){
                    savePayment()
                }
                if (badRes.status > 200) {
                    savePayment()                            
                }
                if (badRes.status == 401) {
                    localStorage.removeItem('access_token');
                    if(localStorage.getItem('email')){
                        window.location.href = "auth/unlock.html"
                    }
                    else{
                        window.location.href = "auth/login.html"
                    }
                    
                }
            }, //ajax error end
        })//ajax end here
    }
    /*------ check mul;tiple decimnl value start ------*/
    $('#received').keypress(function(event) {
        if ((event.which != 46 || $(this).val().indexOf('.') != -1)&&(event.which < 48 || event.which > 57)) {
        //alert('hello');
            if((event.which != 46 || $(this).val().indexOf('.') != -1)){
            alert('Multiple Decimals are not allowed');
          }
          event.preventDefault();
       }
    });
    /*------ check mul;tiple decimnl value end ------*/

    /*------ Toatal calculation -------*/
    $('.modal-body').delegate('#received', 'keyup', function() {
        let prev_balance = $("#prev_balance").val()
        let received = $("#received").val()
        let balance = parseFloat(prev_balance) - parseFloat(received)
        $("#pay_balance").val(parseFloat(balance).toFixed(2))
    });
    /*----- Toatal calculation -------*/
    /*----- Generate Image -------*/    
    $(document).on('click',"#generateImage",function(event){
        $("#loader").show()
        const element = document.getElementById('_invoice');
        let filename = customer.shop_name.toUpperCase()+'_'+pdfId
        var opt =   {
                        margin:       [20,0,0,0],
                        filename:     filename,
                        image:        { type: 'jpeg', quality: 1 },
                        html2canvas:  { scale: 2, dpi: 192, scrollY: 0, letterRendering: true},
                        jsPDF:        { unit: 'pt', format: 'a4', orientation: 'portrait' },
                        pagebreak: { avoid: 'tr', mode: ['avoid-all', 'css', 'legacy'] }
                    };
        html2pdf().set(opt).from(element).toImg().outputImg().then(img =>{
            $("#loader").hide()
            window.plugins.socialsharing.share('Here is your bill' +"\n" +filename, filename, ''+img.src+'')
        });

        // html2pdf().set(opt).from(element).save()

    })
    /*----- Generate Image -------*/
    /*----- Generate pdf -------*/    
    $(document).on('click',"#generatePdf",function(event){
        $("#loader").show()
        const element = document.getElementById('_invoice');
        let filename = customer.shop_name.toUpperCase()+'_'+pdfId
        var opt =   {
                        margin:       [20,0,0,0],
                        filename:     filename,
                        image:        { type: 'jpeg', quality: 1 },
                        html2canvas:  { scale: 2, dpi: 192, scrollY: 0, letterRendering: true},
                        jsPDF:        { unit: 'pt', format: 'a4', orientation: 'portrait' },
                        pagebreak: { avoid: 'table, tr, div', mode: ['avoid-all', 'css', 'legacy'] }
                    };
        // html2pdf().then(function(event){
        //     $("#loader").show()
        // }).set(opt).from(element).save();     

        html2pdf().set(opt).from(element).outputPdf().then(function(pdf) {
            $("#loader").hide()
            window.plugins.socialsharing.share('Here is your bill', filename, 'data:application/pdf;base64,'+btoa(pdf)+'')        

        })         
    })
    /*----- Generate pdf -------*/

    $(document).on('click','a.convert-to-sale',function(e){
        e.preventDefault()
        let trnxxId = $(this).data('trnxid')
        window.location.href = 'orderConvertToSale.html#'+trnxxId+''
    })
})
$(document).ready(function() {
    $("#header").load('layouts/header.html')
    $("#sidebar").load('layouts/sidebar.html')
    $("#footer").load('layouts/footer.html')
    var cartProductDetails = [];
    var cartDetails = {}
    var bottomDetails = {}
    var allCustomer, customerId, roundOff = 0,
        extraCharges = 0,
        deliveryCharges = 0,
        total = 0,
        prevBalance = 0,
        received = 0,
        balance = 0
    var invoiceId = localStorage.getItem('invoice_id')

    function orderDetails() {
        $.ajax({
            method: "GET",
            url: base_url + "api/order/details/" + invoiceId,
            dataType: "json",
            processData: false,
            contentType: false,
            cache: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                'Accept': 'application/json',
                "Authorization": "Bearer " + access_token
            },
            success: function(response) {

                $("#loader").hide()
                var itemNo = 1;
                var order = response.orderDetails
                customerId = order[0].customer_id
                
                for (let count = 0; count < order.length; count++) {
                    $("#cartList").append('<div class="card cart-item mb-2 productCard' + order[count].product_id + '">' +
                        '<div class="card-body">' +
                        '<span class="text-info"># ' + itemNo + '</span>' +
                        '<div class="in">' +
                        '<img src="img/no-img.png" alt="product" class="imaged">' +

                        '<div class="text" style="min-width: 70%">' +
                        '<h3 class="title text-capitalize">' + order[count].product_name + '' +
                        
                        '</h3>' +
                        '<span class="text-secondary text-muted" style="float:right;">MRP: &#8377 ' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(order[count].product_mrp) + '</span>' +

                        '<p class="text-secondary text-muted text-capitalize"><span class="qty">' + order[count].qty + '</span> ' + order[count].unit_name + '</p>' +
                        '<strong class="price amount">&#8377 ' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(order[count].amount) + '</strong>' +
                        '<span class="text-muted text-success" style="float:right;">Discount: <span class="discount' + order[count].product_id + '">&#8377 0</span> </span>' +
                        '</div>' +
                        '</div>' +
                        '<div class="cart-item-footer">' +
                        '<div class="stepper stepper-sm stepper-secondary">' +
                        '<button class="stepper-button stepper-down" data-proid="' + order[count].product_id + '">-</button>' +
                        '<input type="text" class="form-control" value="' + order[count].qty + '" disabled="" name="qty" id="qty">' +

                        '<button class="stepper-button stepper-up" data-proid="' + order[count].product_id + '">+</button>' +
                        '</div>' +
                        '<button class="btn btn-outline-secondary btn-sm discount" data-proid="' + order[count].product_id + '" data-bs-toggle="offcanvas" data-bs-target="#discountModal">Discount</button>' +
                        '<button class="btn btn-outline-secondary btn-sm delProBtn" data-proname="' + order[count].product_name + '" data-proid="' + order[count].product_id + '">Delete</button>' +
                        '</div>' +
                        '</div>' +
                        '</div>')
                    total = parseInt(total) + parseInt(order[count].amount)
                        ++itemNo
                    cartDetails = {
                        selectProductId: order[count].product_id,
                        unitId: order[count].unit_id,
                        price: order[count].product_mrp,
                        qty: order[count].qty,
                        amount: order[count].amount,
                        discount: 0,
                    }
                    cartProductDetails.push(cartDetails);
                }
                $("#invoiceId").html('#'+order[0].invoice_id)
                $("#shopName").html('Shop Name: '+order[0].shop_name)
                $("#locality").html('Location: '+order[0].locality)
                $("#totalAmount").val(total)
                $(".total-mount").html('&#8377 ' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(total))
                prevBalance = order[0].c_balance
                let grandTotal = total + prevBalance
                $(".prev-balance").html('&#8377 ' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(prevBalance))
                $("#prevBalance").val(prevBalance)
                bottomDetails = {
                    roundOff: 0,
                    extraCharges: 0,
                    deliveryCharges: 0,
                    total: total,
                    prevBalance: prevBalance,
                    received: 0,
                    balance: 0
                }
                $(".balance-amount").html('&#8377 ' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(grandTotal))
                $("#footerTotalAmount").html('&#8377 ' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(grandTotal))
                $("#balance").val(grandTotal)
                $("#grand_total_amount").val(grandTotal)
            },
            error: function(badRes) {
                
                if (navigator.onLine == false) {
                    orderDetails();
                }
                if (badRes.status > 200) {
                    orderDetails();
                }
                if (badRes.status == 401) {
                    localStorage.removeItem('access_token');
                    if (localStorage.getItem('email')) {
                        window.location.href = "auth/unlock.html"
                    } else {
                        window.location.href = "auth/login.html"
                    }

                }
            },
        })
    } // orderList function end
    orderDetails()

    $(document).on('click', '.stepper-up', function(event) {
        event.preventDefault()
        let thisProduct = cartProductDetails.filter(elem => {
            return elem.selectProductId == $(this).data('proid');
        })
        let qty = +$(this).prev().val() + 1;
        $(this).prev().val(qty) //this is to show in stepper	            

        let discountPrice = thisProduct[0].price - thisProduct[0].discount
        let amount = discountPrice * qty

        $(this).parent().parent().parent().children('.in').children('.text').children('p.text-secondary').children('.qty').html(qty)
        $(this).parent().parent().parent().children('.in').children('.text').children('.amount').html('&#8377 ' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(amount))


        for (var i = 0; i < cartProductDetails.length; i++) {
            if (cartProductDetails[i].selectProductId == $(this).data('proid')) {
                cartProductDetails = cartProductDetails.filter(function(elem) {
                    return elem != cartProductDetails[i];
                });
            }
        }

        cartDetails = {
            selectProductId: thisProduct[0].selectProductId,
            unitId: thisProduct[0].unitId,
            price: thisProduct[0].price,
            qty: qty,
            amount: amount,
            discount: thisProduct[0].discount,
        }
        cartProductDetails.push(cartDetails);
        bottomValueChange()
    })

    $(document).on('click', '.stepper-down', function(event) {
        event.preventDefault()
        if ($(this).next().val() > 1) {
            let thisProduct = cartProductDetails.filter(elem => {
                return elem.selectProductId == $(this).data('proid');
            })
            let qty = +$(this).next().val() - 1;
            $(this).next().val(qty) //this is to show in stepper	            	

            let discountPrice = thisProduct[0].price - thisProduct[0].discount
            let amount = discountPrice * qty

            $(this).parent().parent().parent().children('.in').children('.text').children('p.text-secondary').children('.qty').html(qty)
            $(this).parent().parent().parent().children('.in').children('.text').children('.amount').html('&#8377 ' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(amount))

            for (var i = 0; i < cartProductDetails.length; i++) {
                if (cartProductDetails[i].selectProductId == $(this).data('proid')) {
                    cartProductDetails = cartProductDetails.filter(function(elem) {
                        return elem != cartProductDetails[i];
                    });

                }
            }

            cartDetails = {
                selectProductId: thisProduct[0].selectProductId,
                unitId: thisProduct[0].unitId,
                price: thisProduct[0].price,
                qty: qty,
                amount: amount,
                discount: thisProduct[0].discount,
            }

            cartProductDetails.push(cartDetails);
            bottomValueChange()
        }
    })

    var footerId, discountProId
    $(document).on('click', 'button.discount', function() {
        let proId = $(this).data('proid')
        discountProId = proId
        $(".discount-label").html('Discount')
        $(".discount-title").html('Discount')
        $("#discountBtn").attr('data-dproid', proId)
    })

    var delProId;
    $(document).on('click', '.delProBtn', function() {
        delProId = $(this).data('proid')
        $("#deleteModal").modal('show')
    })

    $(document).on('click', "#sureDelBtn", function(event) {
        for (var i = 0; i < cartProductDetails.length; i++) {
            if (cartProductDetails[i].selectProductId == delProId) {
                cartProductDetails = cartProductDetails.filter(function(elem) {
                    return elem != cartProductDetails[i];
                });
            }
        }
        $('.productCard' + delProId).remove()
        bottomValueChange()
        $("#deleteModal").modal('hide')
    })

    $("#discountForm").on('click', "#discountBtn", function() {
        let discountAmount = $("#discount_value").val()
        let thisProduct = cartProductDetails.filter(elem => {
            return elem.selectProductId == discountProId;
        })

        let amount = parseInt(thisProduct[0].qty) * (parseInt(thisProduct[0].price) - parseInt(discountAmount))

        for (var i = 0; i < cartProductDetails.length; i++) {
            if (cartProductDetails[i].selectProductId == discountProId) {
                cartProductDetails = cartProductDetails.filter(function(elem) {
                    return elem != cartProductDetails[i];
                });
            }
        }

        cartDetails = {
            selectProductId: thisProduct[0].selectProductId,
            unitId: thisProduct[0].unitId,
            price: thisProduct[0].price,
            qty: thisProduct[0].qty,
            amount: amount,
            discount: discountAmount,
        }
        $('.productCard' + discountProId).children().children('.in').children('.text').children('.amount').html('&#8377 ' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(amount))

        $('.discount' + discountProId).html('&#8377 ' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(discountAmount))
        cartProductDetails.push(cartDetails);
        bottomValueChange()
        setTimeout(function() {
            $("#discountForm")[0].reset()
        }, 100)
    })

    $(document).on('click', '#li_round_off', function() {
        $("#actiontitle").text('Round off')
        $("#actionlabel").text('Round off')
        footerId = '.round-off-amount'
    })
    $(document).on('click', '#li_extChrg', () => {
        $("#actiontitle").html('Extra Chrarges')
        $("#actionlabel").html('Extra Chrarges')
        footerId = '.extChrg-amount'
    })
    $(document).on('click', '#li_deliveryCharge', () => {
        $("#actiontitle").html('Delivery Chrarges')
        $("#actionlabel").html('Delivery Chrarges')
        footerId = '.delivery-amount'
    })
    $(document).on('click', '#li_received', () => {
        $("#actiontitle").html('Received')
        $("#actionlabel").html('Received')
        footerId = '.received-amount'
    })
    $("#actionForm").on('click', "#actionBtn", function() {
        let value = $("#value").val()
        if (footerId == '.round-off-amount') {
            $("#roundOffAmount").val(value)
        }
        if (footerId == '.extChrg-amount') {
            $("#extraCharge").val(value)
        }
        if (footerId == '.delivery-amount') {
            $("#deliveryCharge").val(value)
        }
        if (footerId == '.received-amount') {
            $("#received").val(value)
        }

        $(footerId).html('&#8377 ' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(value))
        setTimeout(function() {
            $("#actionForm")[0].reset()
        }, 100)

        bottomValueChange()
    })

    var grandTotal
    function bottomValueChange() {

        let productSubTotalAmount = 0;
        for (let count = 0; count < cartProductDetails.length; count++) {
            productSubTotalAmount = parseInt(productSubTotalAmount) + parseInt(cartProductDetails[count].amount)
        }
        $("#totalAmount").val(productSubTotalAmount)

        bottomDetails = {}
        bottomDetails = {
            roundOff: $("#roundOffAmount").val(),
            extraCharges: $("#extraCharge").val(),
            deliveryCharges: $("#deliveryCharge").val(),
            total: $("#totalAmount").val(),
            prevBalance: $("#prevBalance").val(),
            received: $("#received").val(),
            balance: $("#balance").val(),
        }

        var total = parseInt(bottomDetails.total) - parseInt(bottomDetails.roundOff)
        total = parseInt(total) + parseInt(bottomDetails.extraCharges)
        total = parseInt(total) + parseInt(bottomDetails.deliveryCharges)
        grandTotal = parseInt(total) + parseInt(bottomDetails.prevBalance)

        $(".total-mount").html('&#8377 ' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(total))
        $(".balance-amount").html('&#8377 ' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(grandTotal))
        $("#footerTotalAmount").html('&#8377 ' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(grandTotal))
        $("#grand_total_amount").val(grandTotal)
        $("#balance").val(grandTotal)
    }

    $(document).on('click',"#placeOrderBtn",function(event){
    	$("#received").val(0)

    })
    $(document).on('keyup',"#received",function(event){
    	event.preventDefault()
    	let balance = $("#grand_total_amount").val() - $("#received").val()
    	$("#balance").val(balance)
        bottomDetails = {
            roundOff: $("#roundOffAmount").val(),
            extraCharges: $("#extraCharge").val(),
            deliveryCharges: $("#deliveryCharge").val(),
            total: $("#totalAmount").val(),
            prevBalance: $("#prevBalance").val(),
            received: $("#received").val(),
            balance: balance,
        }
    })

    $("#paymentForm").on('click',"#paymentBtn",function(event){
    	event.preventDefault()
    	if($("#payment_type").val() == 0){
    		$("#payment_type").css("border-color", "#EC4433");
    	}
    	else{
    		let paymentType = $("#payment_type").val()
            $("#loader").show()
            $("#paymentModal").modal('hide')
    		makePayment(paymentType)
    	}
    })

    function makePayment(paymentType){
		$.ajax({
            type:'POST',
            url: base_url+"api/sale/confirm",
            data: {cartProductDetails : JSON.stringify(cartProductDetails), bottomDetails : JSON.stringify(bottomDetails), 
                    paymentType: JSON.stringify(paymentType), invoiceId: JSON.stringify(invoiceId), customerId: JSON.stringify(customerId)},
            dataType: 'json',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                'Accept': 'application/json',
                "Authorization": "Bearer " + access_token
            },
            success:function(response){
                if(response.success == "OK"){
                    $("#loader").hide()
                    $("#successModal").modal('show')
                }

            },// success end
            error: function (badRes) {
                console.warn(badRes)
                if(navigator.onLine == false){
                    // makePayment();
                }
                if(badRes.status > 200){
                    // makePayment();
                }
                if (badRes.status == 401) {
                    localStorage.removeItem('access_token');
                    if(localStorage.getItem('email')){
                        window.location.href = "auth/unlock.html"
                    }
                    else{
                        window.location.href = "auth/login.html"
                    }
                }
            }, //ajax error end

        });//Ajax End
    }
})
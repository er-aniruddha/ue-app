 $(document).ready(function() {
    $("#header").load('layouts/header.html')
    $("#sidebar").load('layouts/sidebar.html')
    $("#footer").load('layouts/footer.html')    
    var access_token = localStorage.getItem('access_token')        
    function loadInitial(argument) {
        $.ajax({
            method: "GET",
            url: base_url+"api/supplier",
            dataType: "json",
            processData: false,
            contentType: false,
            cache: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                'Accept': 'application/json',
                "Authorization": "Bearer " + access_token
            },
            success: function(response) {
            	console.log(response)
                $("#_listView").empty()
                // $("#customer").addClass('active')
                for (count = 0; count < response.length; count++) {                   
                    $("#_listView").append('<li>' +
                        '<div class="item">' +
                        '<img src="img/avatar1.png" alt="image" class="image">' +
                        '<div class="in">' +
                        '<div id="customerDetails" style="width: 100%;"  data-bs-toggle="offcanvas" data-bs-target="#actionModal">' +
                        '<header class="text-primary text-capitalize" >'+response[count].supplier_name+'</header>'+
                        '<div class="text-capitalize">'+response[count].supplier_address+'</div>'+
                        '<footer class="text-capitalize text-warning inr-sign" style="font-weight: bold; letter-spacing:0.2px;">'+ new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(response[count].balance)+ '</footer>' +
                        '</div>' +
                        '</div>' +
                        '</div>' +
                        '</li>')
                }
                $(".pageTitle").text('Supplier')
                $('#loader').hide();
            }, //success end
            error: function(badRes,t) {
                errortoast(badRes.statusText)
                if(navigator.onLine == false){
                    loadInitial()
                }
                if (badRes.status > 200) {
                    loadInitial()                            
                }
                if (badRes.status == 401) {
                    localStorage.removeItem('access_token');
                    if(localStorage.getItem('email')){
                        window.location.href = "auth/unlock.html"
                    }
                    else{
                        window.location.href = "auth/login.html"
                    }
                    
                }
            }, //ajax error end
        }) //ajax end
    }
    loadInitial()

   

    
    
})
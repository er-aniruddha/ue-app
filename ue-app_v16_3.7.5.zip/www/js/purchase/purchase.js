$(document).ready(function() {
    $("#header").load('layouts/header.html')
    $("#sidebar").load('layouts/sidebar.html')
    $("#footer").load('layouts/footer.html')
    var startDate = moment().subtract(1,'year').format("YYYY-MM-DD")
    var endDate = moment().format("YYYY-MM-DD")
    $("#start_date").val(startDate)
    $("#end_date").val(endDate)
    duDatepicker('#start_date', {
        format: 'yyyy-mm-dd',cancelBtn: true,minDate:moment("2021-01-01"),maxDate:'today',
        // disabledDays: ['Sat', 'Sun'],
        events: {
            dateChanged: function (res) {            
                startDate = res.date                
                purchaseTable.destroy();
                load_table(startDate,endDate)
                loadInitial()
            }
        }
    })
    duDatepicker('#end_date', {
        format: 'yyyy-mm-dd',cancelBtn: true,minDate:moment("2021-01-01"),maxDate:'today',
        // disabledDays: ['Sat', 'Sun'],
        events: {
            dateChanged: function (res) {            
                endDate = res.date
                purchaseTable.destroy();
                load_table(startDate,endDate)
                loadInitial()
            }
        }
    })

    loadInitial()
    load_table(startDate,endDate);

    function loadInitial(argument) {
        $.ajax({
            method: "GET",
            url: base_url+"api/purchase",
            dataType: "json",
            data:{ startDate: startDate, endDate: endDate},
            contentType: false,
            cache: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                'Accept': 'application/json',
                "Authorization": "Bearer " + access_token
            },
            success: function(response) {
                $("#_dateRange").text(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(response.dateRange))
                $("#_thisMonth").text(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(response.thisMonth))
                $("#_7d").text(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(response.sevenDays))
                $(".pageTitle").text('Purchase')
                $("#loader").hide()
                // bottomExpenseDetails()
            }, //success end
            error: function(badRes,t) {
                errortoast(badRes.statusText)
                if(navigator.onLine == false){
                    loadInitial()
                }
                if (badRes.status > 200) {
                    loadInitial()                            
                }
                if (badRes.status == 401) {
                    localStorage.removeItem('access_token');
                    if(localStorage.getItem('email')){
                        window.location.href = "auth/unlock.html"
                    }
                    else{
                        window.location.href = "auth/login.html"
                    }
                    
                }
            }, //ajax error end
        })
    }   

    function load_table(startDate, endDate) {        
        purchaseTable = $("#purchase_table").DataTable({
            dom: 'ltipr',
            processing: true,
            responsive: true,
            serverSide: true,
            "order": [],
            ajax: {
                url:  base_url+"api/purchase/table",
                dataType: "json",
                data:{ startDate: startDate, endDate: endDate},
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                    'Accept': 'application/json',
                    "Authorization": "Bearer " + access_token
                },
            },     
            columns: [{
                    data: "order_date",
                    name: "order_date",
                    render: function(data, type, full, meta) {
                        return '<span class="text-sm text-capitalize">'+moment(data).format('DD-MM-YYYY')+'</span>'
                    },      
                }, {
                    data: "delivery_date",
                    name: "delivery_date",
                    render: function(data, type, full, meta) {
                        if(data){
                            return '<span class="text-sm text-capitalize">'+moment(data).format('DD-MM-YYYY')+'</span>'
                        }
                        if(!data){
                            return '<span class="text-sm item-badge badge text-uppercase bg-warning">Not Deliverd</span>';     
                        }
                    },      
                }, {
                    data: "po_id",
                    name: "po_id",
                    render:function(data){
                        return '<span class="text-sm text-info text-capitalize">CPO-'+data+'</span>';
                    }
                },{
                    data: "name",
                    name: "name",
                },{
                    data: "payment_type",
                    name: "payment_type",
                    render: function(data){
                        if(data == 1){
                            return '<span class="text-sm text-capitalize">Cash</span>'
                        }
                        if(data == 2){
                            return '<span class="text-sm text-capitalize">Online</span>'
                        }
                        if(data == 3){
                            return '<span class="text-sm text-capitalize">Cheque</span>'
                        }
                        if(data == 4){
                            return '<span class="text-sm text-capitalize">Not Paid</span>'
                        }
                    }
                },{
                    data: "total",
                    name: "total",
                    render: function(data){
                        return '<span class="text-sm inr-sign"> '+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
                    }
                },{
                    data: "prev_balance",
                    name: "prev_balance",
                    render: function(data){
                        return '<span class="text-sm inr-sign"> '+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
                    }
                },{
                    data: "advance",
                    name: "advance",
                    render: function(data){
                        return '<span class="text-sm inr-sign"> '+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
                    }
                }, {
                    data: "balance",
                    name: "balance",
                    render: function(data){
                        return '<span class="text-sm inr-sign"> '+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
                    }
                },{
                    data: "payment_status",
                    name: "payment_status",
                    render: function(data){
                        if(data == 0){
                            return '<span class="text-sm text-capitalize text-danger">Unpaid</span>'
                        }
                        if(data == 1){
                            return '<span class="text-sm text-capitalize text-warning">Partial</span>'
                        }
                        if(data == 2){
                            return '<span class="text-sm text-capitalize text-success">Paid</span>'
                        }
                    }
                },{
                    data: "status",
                    name: "status",
                    render: function(data){
                        if(data == 1){
                            return '<span class="text-sm item-badge badge text-uppercase bg-success">Order Complete</span>'
                        }
                        else{
                            '<a class="text-sm item-badge badge text-uppercase bg-secondary convert-to-sale">Convert to Sale</a>'
                        }
                    }
                }],
                

        });
        
    }
    /*------ Sale dataTable end here ------*/


    $(document).on("keyup","#search_input", function() {        
        let name = $(this).val()
        purchaseTable.search(name).draw();
    }); 

    $(document).on('click','#headerCloseBtn',function(event){
        event.preventDefault()
        $("#search_input").val('')
        $("#search_input").attr('placeholder','Search...')
        $("#search").removeClass('show')
    })
})
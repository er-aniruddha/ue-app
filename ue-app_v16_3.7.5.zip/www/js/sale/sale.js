$(document).ready(function() {
    $("#header").load('layouts/header.html')
    $("#sidebar").load('layouts/sidebar.html')
    $("#footer").load('layouts/footer.html')
    var startDate = moment().subtract(1,'year').format("YYYY-MM-DD")
    var endDate = moment().format("YYYY-MM-DD")
    $("#start_date").val(startDate)
    $("#end_date").val(endDate)
    duDatepicker('#start_date', {
        format: 'yyyy-mm-dd',cancelBtn: true,minDate:moment("2021-01-01"),maxDate:'today',
        // disabledDays: ['Sat', 'Sun'],
        events: {
            dateChanged: function (res) {            
                startDate = res.date                
                salesTable.destroy();
                load_table(startDate,endDate)
                loadInitial()
            }
        }
    })
    duDatepicker('#end_date', {
        format: 'yyyy-mm-dd',cancelBtn: true,minDate:moment("2021-01-01"),maxDate:'today',
        // disabledDays: ['Sat', 'Sun'],
        events: {
            dateChanged: function (res) {            
                endDate = res.date
                salesTable.destroy();
                load_table(startDate,endDate)
                loadInitial()
            }
        }
    })

    loadInitial()
    load_table(startDate,endDate);

    function loadInitial(argument) {
        $.ajax({
            method: "GET",
            url: base_url+"api/sale",
            dataType: "json",
            data:{ startDate: startDate, endDate: endDate},
            contentType: false,
            cache: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                'Accept': 'application/json',
                "Authorization": "Bearer " + access_token
            },
            success: function(response) {
                $("#_dateRange").text(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(response.dateRange))
                $("#_thisMonth").text(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(response.thisMonth))
                $("#_7d").text(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(response.sevenDays))
                $(".pageTitle").text('Sale')
                $("#loader").hide()
                // bottomExpenseDetails()
            }, //success end
            error: function(badRes,t) {
                errortoast(badRes.statusText)
                if(navigator.onLine == false){
                    loadInitial()
                }
                if (badRes.status > 200) {
                    loadInitial()                            
                }
                if (badRes.status == 401) {
                    localStorage.removeItem('access_token');
                    if(localStorage.getItem('email')){
                        window.location.href = "auth/unlock.html"
                    }
                    else{
                        window.location.href = "auth/login.html"
                    }
                    
                }
            }, //ajax error end
        })
    }   

    function load_table(startDate, endDate) {        
        salesTable = $("#sale_table").DataTable({
            dom: 'ltipr',
            processing: true,
            responsive: true,
            serverSide: true,
            "order": [],
            ajax: {
                url:  base_url+"api/sale/table",
                dataType: "json",
                data:{ startDate: startDate, endDate: endDate},
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                    'Accept': 'application/json',
                    "Authorization": "Bearer " + access_token
                },
            },     
            columns: [{
                    data: "sale_order_date",
                    name: "sale_order_date",
                    render: function(data, type, full, meta) {
                        return '<span class="text-sm text-capitalize">'+moment(data).format('DD-MM-YYYY')+'</span>'
                    },      
                }, {
                    data: "sale_delivery_date",
                    name: "sale_delivery_date",
                    render: function(data, type, full, meta) {
                        if(data){
                            return '<span class="text-sm text-capitalize">'+moment(data).format('DD-MM-YYYY')+'</span>'
                        }
                        if(!data){
                            return '<span class="text-sm item-badge badge text-uppercase bg-warning">Not Deliverd</span>';     
                        }
                    },      
                }, {
                    data: "sale_trnx_id",
                    name: "sale_trnx_id",
                    render:function(data){
                        return '<span class="text-sm text-success text-capitalize">INV-'+data+'</span>';
                    }
                },{
                    data: "name",
                    name: "name",
                },{
                    data: "sale_payment_type",
                    name: "sale_payment_type",
                    render: function(data){
                        if(data == 1){
                            return '<span class="text-sm text-capitalize">Cash</span>'
                        }
                        if(data == 2){
                            return '<span class="text-sm text-capitalize">Online</span>'
                        }
                        if(data == 3){
                            return '<span class="text-sm text-capitalize">Cheque</span>'
                        }
                        if(data == 4){
                            return '<span class="text-sm text-capitalize">Not Paid</span>'
                        }
                    }
                },{
                    data: "sale_total",
                    name: "sale_total",
                    render: function(data){
                        return '<span class="text-sm inr-sign"> '+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
                    }
                },{
                    data: "sale_prev_balance",
                    name: "sale_prev_balance",
                    render: function(data){
                        return '<span class="text-sm inr-sign"> '+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
                    }
                },{
                    data: "sale_received",
                    name: "sale_received",
                    render: function(data){
                        return '<span class="text-sm inr-sign"> '+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
                    }
                }, {
                    data: "sale_balance",
                    name: "sale_balance",
                    render: function(data){
                        return '<span class="text-sm inr-sign"> '+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
                    }
                },{
                    data: "sale_payment_status",
                    name: "sale_payment_status",
                    render: function(data){
                        if(data == 0){
                            return '<span class="text-sm text-capitalize text-danger">Unpaid</span>'
                        }
                        if(data == 1){
                            return '<span class="text-sm text-capitalize text-warning">Partial</span>'
                        }
                        if(data == 2){
                            return '<span class="text-sm text-capitalize text-success">Paid</span>'
                        }
                    }
                },{
                    data: "sale_status",
                    name: "sale_status",
                    render: function(data){
                        if(data == 1){
                            return '<span class="text-sm item-badge badge text-uppercase bg-success">Order Complete</span>'
                        }
                        else{
                            '<a class="text-sm item-badge badge text-uppercase bg-secondary convert-to-sale">Convert to Sale</a>'
                        }
                    }
                }],               

        });        
    }
    /*------ Sale dataTable end here ------*/
    $(document).on("keyup","#search_input", function() {        
        let name = $(this).val()
        salesTable.search(name).draw();
    }); 

    $(document).on('click','#headerCloseBtn',function(event){
        event.preventDefault()
        $("#search_input").val('')
        $("#search_input").attr('placeholder','Search...')
        $("#search").removeClass('show')
    })

    $(document).on('click','#customerDetails',function(event){
        event.preventDefault()
       localStorage.setItem('customerID', $(this).data('cid'))
       localStorage.setItem('customerType', $(this).data('ctype'))
       localStorage.setItem('customerName',$(this).data('cname'))
       localStorage.setItem('shopName',$(this).data('shopname'))
       localStorage.setItem('phoneNo1',$(this).data('phone1'))
       localStorage.setItem('locality',$(this).data('locality'))
       localStorage.setItem('balance',$(this).data('balance'))
       window.location.href = 'customerProfile.html'
    })
})
  /* *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** ***
  /////////////////   Down Load Button Function   /////////////////
  *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** */
 let customer = 'avisek'
 let pdfId = '123'
$(document).ready(function(){
  $(document).on('click',"#generatePdf",function(event){
        const element = document.getElementById('_invoice');
        let filename = customer.toUpperCase()+'_'+pdfId
        var opt =   {
                        margin:       [20,0,0,0],
                        filename:     filename,
                        image:        { type: 'jpeg', quality: 1 },
                        html2canvas:  { scale: 2, dpi: 192, scrollY: 0, letterRendering: true},
                        jsPDF:        { unit: 'pt', format: 'a4', orientation: 'portrait' },
                        pagebreak: { mode: 'css' }
                    };
        html2pdf().set(opt).from(element).save();     

//         html2pdf().set(opt).from(element).outputPdf().then(function(pdf) {
//             $("#loader").hide()
//             window.plugins.socialsharing.share('Here is your bill', filename, 'data:application/pdf;base64,'+btoa(pdf)+'')        

        })         
})

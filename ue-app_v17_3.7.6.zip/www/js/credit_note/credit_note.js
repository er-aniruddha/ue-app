$(document).ready(function() {
    $("#header").load('layouts/header.html')
    $("#sidebar").load('layouts/sidebar.html')
    $("#footer").load('layouts/footer.html')
    var allTableData
    var startDate = moment().subtract(1,'year').format("YYYY-MM-DD")
    var endDate = moment().format("YYYY-MM-DD")
    $("#start_date").val(startDate)
    $("#end_date").val(endDate)

    duDatepicker('#start_date', {
        format: 'yyyy-mm-dd',cancelBtn: true,minDate:moment("2021-01-01"),maxDate:'today',
        // disabledDays: ['Sat', 'Sun'],
        events: {
            dateChanged: function (res) {            
                startDate = res.date                
                crNoteTable.destroy();
                load_table(startDate,endDate)
                loadInitial()
            }
        }
    })
    duDatepicker('#end_date', {
        format: 'yyyy-mm-dd',cancelBtn: true,minDate:moment("2021-01-01"),maxDate:'today',
        // disabledDays: ['Sat', 'Sun'],
        events: {
            dateChanged: function (res) {            
                endDate = res.date
                crNoteTable.destroy();
                load_table(startDate,endDate)
                loadInitial()
            }
        }
    })

    loadInitial()
    load_table(startDate,endDate);

    function loadInitial(argument) {
        $.ajax({
            method: "GET",
            url: base_url+"api/credit/note",
            dataType: "json",
            data:{ startDate: startDate, endDate: endDate},
            contentType: false,
            cache: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                'Accept': 'application/json',
                "Authorization": "Bearer " + access_token
            },
            success: function(response) {
                allTableData = response.allTableData
                $("#_dateRange").text(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(response.dateRange))
                $("#_thisMonth").text(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(response.thisMonth))
                $("#_7d").text(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(response.sevenDays))
                $(".pageTitle").text('Cr. Note')
                $("#loader").hide()
                // bottomExpenseDetails()
            }, //success end
            error: function(badRes,t) {
                errortoast(badRes.statusText)
                if(navigator.onLine == false){
                    loadInitial()
                }
                if (badRes.status > 200) {
                    loadInitial()                            
                }
                if (badRes.status == 401) {
                    localStorage.removeItem('access_token');
                    if(localStorage.getItem('email')){
                        window.location.href = "auth/unlock.html"
                    }
                    else{
                        window.location.href = "auth/login.html"
                    }
                    
                }
            }, //ajax error end
        })
    }   

    function load_table(startDate, endDate) {        
        crNoteTable = $("#cr_note_table").DataTable({
            dom: 'ltipr',
            processing: true,
            responsive: true,
            serverSide: true,
            "order": [],
            ajax: {
                url:  base_url+"api/credit/note/table",
                dataType: "json",
                data:{ startDate: startDate, endDate: endDate},
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                    'Accept': 'application/json',
                    "Authorization": "Bearer " + access_token
                },
            },     
            columns: [{
                    data: "cr_order_date",
                    name: "cr_order_date",
                    render: function(data, type, full, meta) {
                        return '<span class="text-sm text-capitalize">'+moment(data).format('DD-MM-YYYY')+'</span>'
                    },      
                }, {
                    data: "cr_delivery_date",
                    name: "cr_delivery_date",
                    render: function(data, type, full, meta) {
                        if(data){
                            return '<span class="text-sm text-capitalize">'+moment(data).format('DD-MM-YYYY')+'</span>'
                        }
                        if(!data){
                            return '<span class="text-sm item-badge badge text-uppercase bg-warning">Not Deliverd</span>';     
                        }
                    },      
                }, {
                    data: "cr_trnx_id",
                    name: "cr_trnx_id",
                    render:function(data){
                        return '<span class="text-sm text-warning text-capitalize">CRN-'+data+'</span>';
                    }
                },{
                    data: "name",
                    name: "name",
                },{
                    data: "cr_payment_type",
                    name: "cr_payment_type",
                    render: function(data){
                        if(data == 1){
                            return '<span class="text-sm text-capitalize">Cash</span>'
                        }
                        if(data == 2){
                            return '<span class="text-sm text-capitalize">Online</span>'
                        }
                        if(data == 3){
                            return '<span class="text-sm text-capitalize">Cheque</span>'
                        }
                        if(data == 4){
                            return '<span class="text-sm text-capitalize">Not Paid</span>'
                        }
                    }
                },{
                    data: "cr_total",
                    name: "cr_total",
                    render: function(data){
                        return '<span class="text-sm inr-sign"> '+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
                    }
                },{
                    data: "cr_prev_balance",
                    name: "cr_prev_balance",
                    render: function(data){
                        return '<span class="text-sm inr-sign"> '+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
                    }
                },{
                    data: "cr_received",
                    name: "cr_received",
                    render: function(data){
                        return '<span class="text-sm inr-sign"> '+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
                    }
                }, {
                    data: "cr_balance",
                    name: "cr_balance",
                    render: function(data){
                        return '<span class="text-sm inr-sign"> '+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
                    }
                },{
                    data: "cr_payment_status",
                    name: "cr_payment_status",
                    render: function(data){
                        if(data == 0){
                            return '<span class="text-sm text-capitalize text-danger">Unpaid</span>'
                        }
                        if(data == 1){
                            return '<span class="text-sm text-capitalize text-warning">Partial</span>'
                        }
                        if(data == 2){
                            return '<span class="text-sm text-capitalize text-success">Paid</span>'
                        }
                    }
                },{
                    data: "cr_status",
                    name: "cr_status",
                    render: function(data){
                        if(data == 1){
                            return '<span class="text-sm item-badge badge text-uppercase bg-success">Order Complete</span>'
                        }
                        else{
                            '<a class="text-sm item-badge badge text-uppercase bg-secondary convert-to-sale">Convert to Sale</a>'
                        }
                    }
                }],               

        });        
    }
    /*------ Sale dataTable end here ------*/
    $(document).on("keyup","#search_input", function() {        
        let name = $(this).val()
        crNoteTable.search(name).draw();
    }); 

    $(document).on('click','#headerCloseBtn',function(event){
        event.preventDefault()
        $("#search_input").val('')
        $("#search_input").attr('placeholder','Search...')
        $("#search").removeClass('show')
    })

    $(document).on('click','#customerDetails',function(event){
        event.preventDefault()
       localStorage.setItem('customerID', $(this).data('cid'))
       localStorage.setItem('customerType', $(this).data('ctype'))
       localStorage.setItem('customerName',$(this).data('cname'))
       localStorage.setItem('shopName',$(this).data('shopname'))
       localStorage.setItem('phoneNo1',$(this).data('phone1'))
       localStorage.setItem('locality',$(this).data('locality'))
       localStorage.setItem('balance',$(this).data('balance'))
       window.location.href = 'customerProfile.html'
    })

    /*------- View Start Here -------------*/
    var pdfId,shop_name;
    $("#cr_note_table tbody").on('click','tr td:not(:last-child)',function() { 
        shop_name = crNoteTable.row( this ).data()['shop_name'] 
        let crtrnxId = crNoteTable.row( this ).data()['cr_trnx_id']
        let cr_status = crNoteTable.row( this ).data()['cr_status']
        $('.inv-addedrow').remove();  
    
        if(crtrnxId){
            $('#inv-table').show();
            if(cr_status == 1){
                $("#invTitle").text('Credit Note')
                $('#viewModal .modal-title').text("Credit Note Details: #CRN-"+crtrnxId);
                $('.invoice-id').text("#CRN-"+crtrnxId)
                pdfId = "CRN_"+crtrnxId
            }
            else{
                $("#invTitle").text('Porose Credit Note')
                $('#viewModal .modal-title').text("Credit Note Details: #CRN-OD-"+crtrnxId);
                $('.invoice-id').text("#CRN-OD-"+crtrnxId)
                pdfId = "CRN_OD_"+crtrnxId
            }
            viewCreditNoteDetails(crtrnxId)         
        }
    })    
    /*------- View End Here -------------*/

    function viewCreditNoteDetails(trnxId) {
        for (var count = 0; count < allTableData.length; count++){
            if(trnxId == allTableData[count].cr_trnx_id){
                $("#viewModal").modal('show')
                $('.invoice-to').html('<h4 class="text-capitalize"><i class="bi bi-shop"></i>&nbsp;'+allTableData[count].shop_name+'</h4>'+
                                    '<h3 class="text-capitalize">'+allTableData[count].f_name+' '+allTableData[count].s_name+'</h3>'+
                                    '<p class="text-capitalize"><i class="bi bi-telephone"></i>&nbsp;'+allTableData[count].phone_1+'</p>'+
                                    '<p class="text-capitalize"><i class="bi bi-geo-alt"></i>&nbsp;'+allTableData[count].locality+'</p>')
                $(".invoice-total").html('<ul class="listview transparent simple-listview">'+
                                '<li>Round Off <span class="hightext inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(allTableData[count].cr_round_off)+'</span></li>'+
                                '<li>Delivery Charges <span class="hightext inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(allTableData[count].cr_delivery_charges)+'</span></li>'+
                                '<li>Tax <span class="hightext inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(allTableData[count].cr_gst_amount)+'</span></li>'+
                                '<li>Total<span class="totaltext text-primary inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(allTableData[count].cr_total)+'</span></li>'+
                                '<li>Prev. Balance<span class="hightext text-dark inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(allTableData[count].cr_prev_balance) +'</span></li>'+
                                '<li>Received &#92; Paid <span class="hightext inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(allTableData[count].cr_paid) +'</span></li>'+
                                '<li>Balance <span class="hightext text-danger inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(allTableData[count].cr_balance) +'</span></li>'+
                           '</ul>')

                $("#inv-table").append('<tr class="inv-addedrow">'+
                                '<td>'+allTableData[count].product_name+' - '+allTableData[count].brand_name+ '</td>'+
                                '<td>'+allTableData[count].cr_qty+'('+allTableData[count].unit_code+')</td>'+
                                '<td class="inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(allTableData[count].cr_unit_price)+'</td>'+
                                '<td class="">0.00 %</td>'+
                                '<td class="inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(0)+'</td>'+
                                '<td class="inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(allTableData[count].cr_amount)+'</td>'+                                        
                            '</tr>')
                $(".order-date").html('<p>Order Date : '+moment(allTableData[count].cr_order_date, 'YYYY-MM-DD').format("DD-MM-YYYY")+'</p>')

                if(allTableData[count].cr_delivery_date){
                    $(".delivery_date").html('<p>Delivery Date : '+moment(allTableData[count].cr_delivery_date, 'YYYY-MM-DD').format("DD-MM-YYYY")+'</p>')
                }
                else{
                    $(".delivery_date").html('<p>Delivery Date : NOT DELIVERED</p>')
                }
                
                if(allTableData[count].cr_payment_type == 1){
                    $(".payment-type").html('<p>Payment Type : Cash</p>')
                }
                if(allTableData[count].cr_payment_type == 2){
                    $(".payment-type").html('<p>Payment Type : Online</p>')
                }
                if(allTableData[count].cr_payment_type == 3){
                    $(".payment-type").html('<p>Payment Type : Cheque</p>')
                } 
                if(allTableData[count].cr_payment_type == 4){
                    $(".payment-type").html('<p>Payment Type : No Payment</p>')
                } 
                
            }
        }
    }

    /*----- Generate Image -------*/    
    $(document).on('click',"#generateImage",function(event){
        $("#loader").show()
        const element = document.getElementById('_invoice');
        let filename = shop_name.toUpperCase()+'_'+pdfId
        var opt =   {
                        margin:       [20,0,0,0],
                        filename:     filename,
                        image:        { type: 'jpeg', quality: 1 },
                        html2canvas:  { scale: 2, dpi: 192, scrollY: 0, letterRendering: true},
                        jsPDF:        { unit: 'pt', format: 'a4', orientation: 'portrait' },
                        pagebreak: { avoid: 'tr', mode: ['avoid-all', 'css', 'legacy'] }
                    };
        html2pdf().set(opt).from(element).toImg().outputImg().then(img =>{
            $("#loader").hide()
            window.plugins.socialsharing.share('Here is your bill' +"\n" +filename, filename, ''+img.src+'')
        });

        // html2pdf().set(opt).from(element).save()

    })
    /*----- Generate Image -------*/
    /*----- Generate pdf -------*/    
    $(document).on('click',"#generatePdf",function(event){
        $("#loader").show()
        const element = document.getElementById('_invoice');
        let filename = shop_name.toUpperCase()+'_'+pdfId
        var opt =   {
                        margin:       [20,0,0,0],
                        filename:     filename,
                        image:        { type: 'jpeg', quality: 1 },
                        html2canvas:  { scale: 2, dpi: 192, scrollY: 0, letterRendering: true},
                        jsPDF:        { unit: 'pt', format: 'a4', orientation: 'portrait' },
                        pagebreak: { avoid: 'table, tr, div', mode: ['avoid-all', 'css', 'legacy'] }
                    };
        // html2pdf().then(function(event){
        //     $("#loader").show()
        // }).set(opt).from(element).save();     

        html2pdf().set(opt).from(element).outputPdf().then(function(pdf) {
            $("#loader").hide()
            window.plugins.socialsharing.share('Here is your bill', filename, 'data:application/pdf;base64,'+btoa(pdf)+'')        

        })         
    })
    /*----- Generate pdf -------*/

    $(document).on('click','#customerDetails',function(event){
        event.preventDefault()
       localStorage.setItem('customerID', $(this).data('cid'))
       localStorage.setItem('customerType', $(this).data('ctype'))
       localStorage.setItem('customerName',$(this).data('cname'))
       localStorage.setItem('shopName',$(this).data('shopname'))
       localStorage.setItem('phoneNo1',$(this).data('phone1'))
       localStorage.setItem('locality',$(this).data('locality'))
       localStorage.setItem('balance',$(this).data('balance'))
       window.location.href = 'customerProfile.html'
    })
})
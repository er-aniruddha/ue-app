$(document).ready(function() {
    $("#header").load('layouts/header.html')
    $("#sidebar").load('layouts/sidebar.html')
    $("#footer").load('layouts/footer.html')
    var access_token = localStorage.getItem('access_token')     
    var customerId = localStorage.getItem('customerID')   
    function route(argument) {
        $.ajax({
            method: "GET",
            url: base_url+"api/route",
            dataType: "json",
            processData: false,
            contentType: false,
            cache: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                'Accept': 'application/json',
                "Authorization": "Bearer " + access_token
            },
            success:function(response){
                for(let count=0; count < response.length; count++){
                    $("#customer_routes_id ").append('<option value="'+response[count].customer_routes_id+'">'+response[count].route_name+'</option>')
                }
                $("#customer_id").val(customerId)
                customerDetails()
            },
            error:function(badRes){
                errortoast(badRes.statusText)
                if(navigator.onLine == false){
                    route()
                }
                if (badRes.status > 200) {
                    route()                            
                }
                if (badRes.status == 401) {
                    localStorage.removeItem('access_token');
                    if(localStorage.getItem('email')){
                        window.location.href = "auth/unlock.html"
                    }
                    else{
                        window.location.href = "auth/login.html"
                    }
                    
                }
            },
        })
    }
    route()
    function customerDetails(argument) {
        $.ajax({
            method: "GET",
            url: base_url+"api/customer/profile/"+customerId,
            dataType: "json",
            processData: false,
            contentType: false,
            cache: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                'Accept': 'application/json',
                "Authorization": "Bearer " + access_token
            },
            success: function(response) {
                let customer = response.customer
                $("#f_name").val(customer.f_name)
                $("#s_name").val(customer.s_name)
                $("#shop_name").val(customer.shop_name)                            
                $("#phone_1").val(customer.phone_1)
                $("#phone_2").val(customer.phone_2)
                $("#whatsapp_no").val(customer.whatsapp_no)
                $("#email").val(customer.email)
                $("#customer_type").select2({width:"100%"}).val(customer.customer_type).trigger("change");
                $("#customer_routes_id").select2({width:"100%"}).val(customer.customer_routes_id).trigger("change");
                $("#locality").val(customer.locality)
                $("#district").select2({width:"100%"}).val(customer.district).trigger("change");
                $("#pin").val(customer.pin)
                $("#addline_1").val(customer.addline_1)
                $("#addline_2").val(customer.addline_2)
                $("#appHeader").addClass('is-active')
                $(".pageTitle").text('Edit Customer Profile')
                $("#searchBtn").remove()
                $('#loader').hide();
                $('.appBottomMenu').remove();
            }, //success end
            error: function(badRes,t) {
                errortoast(badRes.statusText)
                if(navigator.onLine == false){
                    customerDetails()
                }
                if (badRes.status > 200) {
                    customerDetails()                            
                }
                if (badRes.status == 401) {
                    localStorage.removeItem('access_token');
                    if(localStorage.getItem('email')){
                        window.location.href = "auth/unlock.html"
                    }
                    else{
                        window.location.href = "auth/login.html"
                    }
                    
                }
            }, //ajax error end
        }) //ajax end
    }
    $('.select2').select2({ 
        width:"100%",
    }); 

    $("#editCustomer").on('click','#updateBtn',function(event){
        event.preventDefault()
        $(".text-danger").html("")
        $("#loader").show()
        var postData = new FormData($("#editCustomer")[0]);
        editCustomer(postData)
    })// edit form end

    function editCustomer(postData){
         $.ajax({
            method: "POST",
            url: base_url+"api/customer/profile/update",
            data: postData,
            dataType: "json",
            processData: false,
            contentType: false,
            cache: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                'Accept': 'application/json',
                "Authorization": "Bearer " + access_token
            },
            success:function(response){                        
                $("#loader").hide()
                if(response.errors){
                    if(response.errors.f_name){
                        $("#f_name_error").text(response.errors.f_name[0])
                    }
                    if(response.errors.s_name){
                        $("#s_name_error").text(response.errors.s_name[0])
                    }
                    if(response.errors.shop_name){
                        $("#shop_name_error").text(response.errors.shop_name[0])
                    }
                    if(response.errors.phone_1){
                        $("#phone_1_error").text(response.errors.phone_1[0])
                    }
                    if(response.errors.phone_2){
                        $("#phone_2_error").text(response.errors.phone_2[0])
                    }
                    if(response.errors.whatsapp_no){
                        $("#whatsapp_no_error").text(response.errors.whatsapp_no[0])
                    }
                    if(response.errors.customer_type){
                        $("#customer_type_error").text(response.errors.customer_type[0])
                    }
                    if(response.errors.customer_routes_id){
                        $("#route_error").text(response.errors.customer_routes_id[0])
                    }
                    if(response.errors.locality){
                        $("#locality_error").text(response.errors.locality[0])
                    }
                    if(response.errors.district){
                        $("#district_error").text(response.errors.district[0])
                    }
                    if(response.errors.pin){
                        $("#pin_error").text(response.errors.pin[0])
                    }
                    if(response.errors.email){
                        $("#email_error").text(response.errors.email[0])
                    }
                }
                if(response.success == "OK"){
                    notification(response.message)
                    setTimeout(function(){
                        var prevUrl =  document.referrer
                        window.location.href = prevUrl
                    },2000)
                }
            },
            error:function(badRes){
                errortoast(badRes.statusText)
                if(navigator.onLine == false){
                    editCustomer()
                }
                if (badRes.status > 200) { 
                    editCustomer()                       
                }
                if (badRes.status == 401) {
                    localStorage.removeItem('access_token');
                    if(localStorage.getItem('email')){
                        window.location.href = "auth/unlock.html"
                    }
                    else{
                        window.location.href = "auth/login.html"
                    }
                    
                }
            },
        })// ajax end
    }

     /*----- on cancl button click -----*/
    $(document).on('click','#closeBtn',function(event){
        event.preventDefault()
        var prevUrl =  document.referrer
        window.location.href = prevUrl
    })
    /*----- on cancl button click -----*/
})
$(document).ready(function(){
	base_url_img = "https://varneyatechnologies.com"
	base_url = "https://account.varneyatechnologies.com/"
	// base_url = "http://192.168.100.150/edission/v2/"
	routes = [		
		{'id':'back', 'name': 'back', 'InAppBrowser': false},
		{'id':'login', 'name': 'auth/login.html', 'InAppBrowser': false},
		{'id':'unlock', 'name': 'auth/unlock.html', 'InAppBrowser': false},
		{'id':'forgotPassword', 'name': 'forgotpassword.html', 'InAppBrowser': false},
		{'id':'home', 'name': 'index.html', 'InAppBrowser': false},
		{'id':'customer', 'name': 'customer.html', 'InAppBrowser': false},
		{'id':'addCustomer', 'name': 'customerCreate.html', 'InAppBrowser': false},
		{'id':'customerProfile', 'name': 'customerProfile.html', 'InAppBrowser': false},
		{'id':'customerTransactionView', 'name': 'customerTransactionView.html', 'InAppBrowser': false},
		{'id':'editCustomer', 'name': 'customerEdit.html', 'InAppBrowser': false},
		{'id':'expense', 'name': 'expense.html', 'InAppBrowser': false},
		{'id':'order', 'name': 'order.html', 'InAppBrowser': false},
		{'id':'orderList', 'name': 'orderList.html', 'InAppBrowser': false},
		{'id':'paymentIn', 'name': 'paymentIn.html', 'InAppBrowser': false},
		{'id':'_schemeEntry', 'name': 'scheme.html', 'InAppBrowser': false},
		{'id':'account', 'name': 'account.html', 'InAppBrowser': false},
		{'id':'product', 'name': 'product.html', 'InAppBrowser': false},
		{'id':'sale', 'name': 'sale.html', 'InAppBrowser': false},
		{'id':'purchase', 'name': 'purchase.html', 'InAppBrowser': false},
		{'id':'crnote', 'name': 'credit-note.html', 'InAppBrowser': false},
		{'id':'supplier', 'name': 'supplier.html', 'InAppBrowser': false},
		{'id':'lAccount', 'name': 'loan-account.html', 'InAppBrowser': false},
		{'id':'error', 'name': 'error.html', 'InAppBrowser': false},
	]

	$(document).on('click','a.route',function(event){
		event.preventDefault()
		if($(this).attr('href') != '#'){
			let urlId = $(this).attr('id')
			$('#loader').show();
			route(urlId)
		}		
	})  		
	var inAppBrowserRef;

	window.route =  function (urlId) {
		let url = routes.filter(elem => {
            return elem.id == urlId;
        })        
        console.log(url)
        if (url[0].InAppBrowser == true) {
        	showHelp(url[0].name)        	
        }
        else{
        	if(url[0].name == 'back'){
        		window.history.back();
        	}
        	else{
        		window.location.href = url[0].name
        	}
        }        
	}

	function showHelp(url) {
	    var target = "_blank";
	    var options = "location=no,hidden=yes,fullscreen=no,zoom=no,closebuttoncaption=yes";
	    inAppBrowserRef = cordova.InAppBrowser.open(url, target, options);
	    inAppBrowserRef.addEventListener('loaderror', loadErrorCallBack);
	    inAppBrowserRef.addEventListener('loadstop', loadStopCallBack);	    
	    inAppBrowserRef.addEventListener('exit', loadExitCallBack);	    
	}

	function loadErrorCallBack(params) {
		alert('error:'+params.message)
		inAppBrowserRef.close();
		$('#errorModal').modal('show')
		$('#loader').hide();
	}

	function loadStopCallBack() {
		inAppBrowserRef.show();
	}

	function loadExitCallBack() {
		$('#loader').hide();
	}

})
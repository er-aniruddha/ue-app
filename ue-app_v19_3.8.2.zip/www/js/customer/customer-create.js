$(document).ready(function() {
    $("#header").load('layouts/header.html')
    $("#sidebar").load('layouts/sidebar.html')
    $("#footer").load('layouts/footer.html')
    var access_token = localStorage.getItem('access_token')     

    /*----- to show routes in form -----*/
    function salesRoute(argument) {
        $.ajax({
            method: "GET",
            url: base_url+"api/route",
            dataType: "json",
            processData: false,
            contentType: false,
            cache: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                'Accept': 'application/json',
                "Authorization": "Bearer " + access_token
            },
            success:function(response){
            	 $("#loader").hide()
                for(let count=0; count < response.length; count++){
                    $("#customer_routes_id").append('<option value="'+response[count].customer_routes_id+'">'+response[count].route_name+'</option>')
                }
                 $('.select2').select2({ 
	                width:"100%",
	            });
	        },
            error:function(badRes){
                errortoast(badRes.statusText)
                if(navigator.onLine == false){
                    salesRoute()
                }
                if (badRes.status > 200) {
                    salesRoute()                            
                }
                if (badRes.status == 401) {
                    localStorage.removeItem('access_token');
                    if(localStorage.getItem('u_email')){
                        window.location.href = "auth/unlock.html"
                    }
                    else{
                        window.location.href = "auth/login.html"
                    }
                    
                }
            },
        })
    }
    salesRoute()
    /*----- to show routes in form -----*/

    $("#createCustomer").on('click','#saveBtn',function(event){
        event.preventDefault()
        $(".text-danger").html("")
        $("#loader").show()
        var postData = new FormData($("#createCustomer")[0]);
        createCustomer(postData)
    })// edit form end

    function createCustomer(postData){
         $.ajax({
            method: "POST",
            url: base_url+"api/customer/create",
            data: postData,
            dataType: "json",
            processData: false,
            contentType: false,
            cache: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                'Accept': 'application/json',
                "Authorization": "Bearer " + access_token
            },
            success:function(response){                        
                $("#loader").hide()
                if(response.errors){
                    if(response.errors.f_name){
                        $("#f_name_error").text(response.errors.f_name[0])
                    }
                    if(response.errors.s_name){
                        $("#s_name_error").text(response.errors.s_name[0])
                    }
                    if(response.errors.shop_name){
                        $("#shop_name_error").text(response.errors.shop_name[0])
                    }
                    if(response.errors.phone_1){
                        $("#phone_1_error").text(response.errors.phone_1[0])
                    }
                    if(response.errors.phone_2){
                        $("#phone_2_error").text(response.errors.phone_2[0])
                    }
                    if(response.errors.whatsapp_no){
                        $("#whatsapp_no_error").text(response.errors.whatsapp_no[0])
                    }
                    if(response.errors.customer_type){
                        $("#customer_type_error").text(response.errors.customer_type[0])
                    }
                    if(response.errors.customer_routes_id){
                        $("#route_error").text(response.errors.customer_routes_id[0])
                    }
                    if(response.errors.locality){
                        $("#locality_error").text(response.errors.locality[0])
                    }
                    if(response.errors.district){
                        $("#district_error").text(response.errors.district[0])
                    }
                    if(response.errors.pin){
                        $("#pin_error").text(response.errors.pin[0])
                    }
                    if(response.errors.email){
                        $("#email_error").text(response.errors.email[0])
                    }
                    if(response.errors.tag_sales){
                        $("#tag_sales_error").text(response.errors.tag_sales[0])
                    }
                }
                if(response.success == "OK"){
                    notification(response.message) 
                    setTimeout(function(){
                        var prevUrl =  document.referrer
                        window.location.href = prevUrl
                    },2000)
                }
            },
            error:function(badRes){
                errortoast(badRes.statusText)
                if(navigator.onLine == false){
                    createCustomer()
                }
                if (badRes.status > 200) { 
                    createCustomer()                       
                }
                if (badRes.status == 401) {
                    localStorage.removeItem('access_token');
                    if(localStorage.getItem('u_email')){
                        window.location.href = "auth/unlock.html"
                    }
                    else{
                        window.location.href = "auth/login.html"
                    }
                    
                }
            },
        })// ajax end
    }

    /*----- on cancl button click -----*/
    $(document).on('click','#closeBtn',function(event){
    	event.preventDefault()
    	var prevUrl =  document.referrer
        window.location.href = prevUrl
    })
    /*----- on cancl button click -----*/
})
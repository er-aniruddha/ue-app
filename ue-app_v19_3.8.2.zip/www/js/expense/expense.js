$(document).ready(function() {
    $("#header").load('layouts/header.html')
    $("#sidebar").load('layouts/sidebar.html')
    $("#footer").load('layouts/footer.html')
    var allExpense;
    var startDate = moment().subtract(1,'year').format("YYYY-MM-DD")
    var endDate = moment().format("YYYY-MM-DD")
    $("#start_date").val(startDate)
    $("#end_date").val(endDate)

    duDatepicker('#start_date', {
        format: 'yyyy-mm-dd',cancelBtn: true,minDate:moment("2021-01-01"),maxDate:'today',
        // disabledDays: ['Sat', 'Sun'],
        events: {
            dateChanged: function (res) {            
                startDate = res.date                
                expenseTable.destroy();
                load_table(startDate,endDate)
                loadInitial()
            }
        }
    })
    duDatepicker('#end_date', {
        format: 'yyyy-mm-dd',cancelBtn: true,minDate:moment("2021-01-01"),maxDate:'today',
        // disabledDays: ['Sat', 'Sun'],
        events: {
            dateChanged: function (res) {            
                endDate = res.date
                expenseTable.destroy();
                load_table(startDate,endDate)
                loadInitial()
            }
        }
    })

    loadInitial()
    load_table(startDate,endDate);

    function loadInitial(argument) {
        $.ajax({
            method: "GET",
            url: base_url+"api/expense",
            dataType: "json",
            data:{ startDate: startDate, endDate: endDate},
            contentType: false,
            cache: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                'Accept': 'application/json',
                "Authorization": "Bearer " + access_token
            },
            success: function(response) {
            	allExpense = response.allExpense
                $("#_dateRange").text(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(response.dateRange))
                $("#_thisMonth").text(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(response.thisMonth))
                $("#_7d").text(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(response.sevenDays))
                $(".pageTitle").text('Expense')
                $("#loader").hide()
            }, //success end
            error: function(badRes,t) {
                errortoast(badRes.statusText)
                if(navigator.onLine == false){
                    loadInitial()
                }
                if (badRes.status > 200) {
                    loadInitial()                            
                }
                if (badRes.status == 401) {
                    localStorage.removeItem('access_token');
                    if(localStorage.getItem('u_email')){
                        window.location.href = "auth/unlock.html"
                    }
                    else{
                        window.location.href = "auth/login.html"
                    }
                    
                }
            }, //ajax error end
        })
    }   

    function load_table(startDate, endDate) {        
        expenseTable = $("#expense_table").DataTable({
            dom: 'ltipr',
            processing: true,
            responsive: true,
            serverSide: true,
            "order": [],
            ajax: {
                url:  base_url+"api/expense/table",
                dataType: "json",
                data:{ startDate: startDate, endDate: endDate},
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                    'Accept': 'application/json',
                    "Authorization": "Bearer " + access_token
                },
            },     
            columns: [{
                data: "date",
                name: "date",
                render: function(data){
                    return '<span class="text-sm">'+moment(data).format('DD-MM-YYYY')+'</span>'
                }
            }, {
                data: "fuel",
                name: "fuel",
                render: function(data){
                    return '<span class="text-sm inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
                }
            },{
                data: "travelling",
                name: "travelling",
                render: function(data){
                    return '<span class="text-sm inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
                }
            }, {
                data: "transport",
                name: "transport",
                render: function(data){
                    return '<span class="text-sm inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
                }
            }, {
                data: "tiffin",
                name: "tiffin",
                render: function(data){
                    return '<span class="text-sm inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
                }
            },
            {
                data: "room_rent",
                name: "room_rent",
                render: function(data){
                    return '<span class="text-sm inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
                }
            },
            {
                data: "salary",
                name: "salary",
                render: function(data){
                    return '<span class="text-sm">&#8377; '+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
                }
            }, {
                data: "extra_exp",
                name: "extra_exp",
                render: function(data){
                    return '<span class="text-sm inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
                }
            },{
                data: "total",
                name: "total",
                render: function(data){
                    return '<span class="text-sm text-primary inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
                }
            },{
            	render: function(data){
                    return '<a class="text-sm text-danger mx-4" style="white-space:nowrap"><i class="bi bi-trash"></i></a>'
                }
            }],               

        });        
    }
    /*------ Sale dataTable end here ------*/
    $(document).on("keyup","#search_input", function() {        
        let name = $(this).val()
        expenseTable.search(name).draw();
    }); 

    $(document).on('click','#headerCloseBtn',function(event){
        event.preventDefault()
        $("#search_input").val('')
        $("#search_input").attr('placeholder','Search...')
        $("#search").removeClass('show')
    })

    $(document).on('click','#expenseModalBtn',function(event){
        event.preventDefault()
        $("#expenseForm .text-danger").html("")
        $('#expenseForm')[0].reset();
        var postData = new FormData($("#expenseForm")[0]);
        $("#date").attr('disabled',false)
        $("#expenseModal").modal('show')
        $('#saveBtn').show()
        $('#updateBtn').hide()
        $(".modal-title").text("Add Expense") 
    })

    /*------ To check decimal value -----*/
    $('#fuel, #travelling ,#transport, #tiffin, #room_rent, #salary, #extra_exp').keypress(function(event) {
        if ((event.which != 46 || $(this).val().indexOf('.') != -1)&&(event.which < 48 || event.which > 57)) {
        //alert('hello');
            if((event.which != 46 || $(this).val().indexOf('.') != -1)){
            alert('Multiple Decimals are not allowed');
          }
          event.preventDefault();
       }
    });
    /*------ To check decimal value -----*/

    /*----- Total calculation ------*/
    $(document).delegate('#fuel, #travelling ,#transport, #tiffin, #room_rent, #salary, #extra_exp', 'keyup', function() {
        let fuel = $("#fuel").val()
        let travelling = $("#travelling").val()
        let transport = $("#transport").val()
        let tiffin = $("#tiffin").val()
        let room_rent = $("#room_rent").val()
        let salary = $("#salary").val()
        let extra_exp = $("#extra_exp").val()
        let total = (+fuel)+(+travelling)+(+transport)+(+tiffin)+(+room_rent)+(+salary)+(+extra_exp)
        $("#total").val(total.toFixed(2))
    });
    /*----- Total calculation ------*/

    /*----- save expense form -----*/
    $("#expenseForm").on('click','#saveBtn',function(event){
        event.preventDefault()
        $("#expenseForm .text-danger").html("")
        $("#loader").show()
        var postData = new FormData($("#expenseForm")[0]);
        saveExpense(postData)
    })

    function saveExpense(postData) {
        $("#loader").show()
        $.ajax({
            method: "POST",
            url: base_url+"api/expense/create",
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: postData,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                'Accept': 'application/json',
                "Authorization": "Bearer " + access_token
            },
            success: function(response) {
                $("#loader").hide()
                if (response.errors) {
                    if(response.errors.date){
                        $("#date_error").text(response.errors.date[0])
                    }
                    if(response.errors.fuel){
                        $("#fuel_error").text(response.errors.fuel[0])
                    }
                    if(response.errors.travelling){
                        $("#travelling_error").text(response.errors.travelling[0])
                    }
                    if(response.errors.transport){
                        $("#transport_error").text(response.errors.transport[0])
                    }
                    if(response.errors.tiffin){
                        $("#tiffin_error").text(response.errors.tiffin[0])
                    }
                    if(response.errors.room_rent){
                        $("#room_rent_error").text(response.errors.room_rent[0])
                    }
                    if(response.errors.salary){
                        $("#salary_error").text(response.errors.salary[0])
                    }
                    if(response.errors.extra_exp){
                        $("#extra_exp_error").text(response.errors.extra_exp[0])
                    }
                    if(response.errors.total){
                        $("#total_error").text(response.errors.total[0])
                    }
                    if(response.errors.remarks){
                        $("#remarks_error").text(response.errors.remarks[0])
                    }
                }                    
                if(response.success == "OK") {
                    notification(response.message)  
                    $("#expenseModal").modal('hide')
                    $('input').attr('value' , '')
                    loadInitial()
                    expenseTable.destroy();
                	load_table(startDate,endDate)
                }
            }, //success end
            error:function(badRes){
                errortoast(badRes.statusText)
                if(navigator.onLine == false){
                    saveExpense()
                }
                if (badRes.status > 200) { 
                    saveExpense()                       
                }
                if (badRes.status == 401) {
                    localStorage.removeItem('access_token');
                    if(localStorage.getItem('u_email')){
                        window.location.href = "auth/unlock.html"
                    }
                    else{
                        window.location.href = "auth/login.html"
                    }
                    
                }
            }, //error end
        }) //ajax end
    }        
    /*----- save expense form -----*/

    /*----- on cancl button click -----*/
    $(document).on('click','#closeBtn',function(event){
        event.preventDefault()
        $("#expenseModal").modal('hide')
    })
    /*----- on cancl button click -----*/

    duDatepicker('#date', {
        format: 'dd-mm-yyyy', clearBtn: true, minDate:moment("2022-01-01"),maxDate: 'today'
        // disabledDays: ['Sat', 'Sun'],
    })

    $("#expense_table tbody").on('click','tr td:not(:last-child)',function() { 
    	let expense_id = expenseTable.row( this ).data()['expense_id']
    	let thisExpense = allExpense.filter(elem => {
            return elem.expense_id == expense_id;
        })       
        $("#expenseForm .text-danger").html("")    
        $(".modal-title").text("Expense Details")        
        $('#saveBtn').hide()
        $('#updateBtn').show()
        showModal(thisExpense)
    })

    $("#expenseForm").on('click','#updateBtn',function(event){
        event.preventDefault()
        $("#expenseForm .text-danger").html("")
        $("#loader").show()
        var postData = new FormData($("#expenseForm")[0]);
        updateExpense(postData)
    })

    function updateExpense(postData) {
        $.ajax({
            method: "POST",
            url: base_url+"api/expense/update",
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            data: postData,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                'Accept': 'application/json',
                "Authorization": "Bearer " + access_token
            },
            success: function(response) {
                $("#loader").hide()
                if (response.errors) {
                    if(response.errors.date){
                        $("#date_error").text(response.errors.date[0])
                    }
                    if(response.errors.fuel){
                        $("#fuel_error").text(response.errors.fuel[0])
                    }
                    if(response.errors.travelling){
                        $("#travelling_error").text(response.errors.travelling[0])
                    }
                    if(response.errors.transport){
                        $("#transport_error").text(response.errors.transport[0])
                    }
                    if(response.errors.tiffin){
                        $("#tiffin_error").text(response.errors.tiffin[0])
                    }
                    if(response.errors.room_rent){
                        $("#room_rent_error").text(response.errors.room_rent[0])
                    }
                    if(response.errors.salary){
                        $("#salary_error").text(response.errors.salary[0])
                    }
                    if(response.errors.extra_exp){
                        $("#extra_exp_error").text(response.errors.extra_exp[0])
                    }
                    if(response.errors.total){
                        $("#total_error").text(response.errors.total[0])
                    }
                    if(response.errors.remarks){
                        $("#remarks_error").text(response.errors.remarks[0])
                    }
                }                    
                else {
                    notification(response.message)  
                    $("#expenseModal").modal('hide')
                    $('input').attr('value' , '')
                    loadInitial()
                    expenseTable.destroy();
                	load_table(startDate,endDate)
                }
            }, //success end
            error:function(badRes){
                errortoast(badRes.statusText)
                if(navigator.onLine == false){
                    updateExpense()
                }
                if (badRes.status > 200) { 
                    updateExpense()                       
                }
                if (badRes.status == 401) {
                    localStorage.removeItem('access_token');
                    if(localStorage.getItem('u_email')){
                        window.location.href = "../auth/unlock.html"
                    }
                    else{
                        window.location.href = "../auth/login.html"
                    }
                    
                }
            }, //error end
        }) //ajax end
    }        
    /*----- update expense form -----*/

    function showModal(thisExpense) {                
        $("#date").val(moment(thisExpense[0].date).format('DD-MM-YYYY'))
        $("#fuel").val(thisExpense[0].fuel)
        $("#travelling").val(thisExpense[0].travelling)
        $("#transport").val(thisExpense[0].transport)
        $("#tiffin").val(thisExpense[0].tiffin)
        $("#room_rent").val(thisExpense[0].room_rent)
        $("#salary").val(thisExpense[0].salary)
        $("#extra_exp").val(thisExpense[0].extra_exp)
        $("#total").val(thisExpense[0].total)
        $("#remarks").val(thisExpense[0].remarks)
        $("#expense_id").val(thisExpense[0].expense_id)
        $("#expenseModal").modal("show") 
        $(".error-text").html("")
    }

    var expense_id
    $("#expense_table tbody").on('click','tr td:last-child',function() {       
        let data = expenseTable.row( this ).data()
        expense_id = data['expense_id']
        $('#errorModal .modal-body').html("Are you sure to delete this expense: "+moment(data.date).format("DD-MM-YYYY")+" ??")                
        $("#errorModalFooter").remove()
        $(".error-modal-content").append('<div class="modal-footer" id="errorModalFooter">'+
                '<div class="btn-inline">'+
                    '<button class="btn btn-text-danger" id="sureDelBtn">'+
                        '<ion-icon name="trash-outline" role="img" class="md hydrated" aria-label="trash outline"></ion-icon>'+
                        'DELETE </button>'+
                    '<button class="btn btn-text-primary" data-bs-dismiss="modal">'+
                        '<ion-icon name="close-circle-outline" role="img" class="md hydrated" aria-label="close-circle-outline"></ion-icon>'+
                       ' CLOSE </button>'+
                '</div>'+
            '</div>')
         $(".modal-title").text("Delete Expense")       
        $("#errorModal").modal('show')
    })

    $(document).on('click','#sureDelBtn',function(event){
        event.preventDefault()
        sureDeleteExpense()
    })

    function sureDeleteExpense() {
        $.ajax({
            method: "GET",
            url: base_url+"api/expense/delete/"+expense_id,
            dataType: "json",
            processData: false,
            contentType: false,
            cache: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                'Accept': 'application/json',
                "Authorization": "Bearer " + access_token
            },
            success:function(response){
                $("#errorModal").modal('hide')
                if(response.success){
                    notification(response.success)   
                    $('#loader').show();
                    loadInitial()
                    expenseTable.destroy();
                	load_table(startDate,endDate)
                }
                if(response.error){
                    notification(response.error) 
                }
            },
            error:function(badRes){
                errortoast(badRes.statusText)
                if(navigator.onLine == false){
                    sureDeleteExpense()
                }
                if (badRes.status > 200) {
                    sureDeleteExpense()                            
                }
                if (badRes.status == 401) {
                    localStorage.removeItem('access_token');
                    if(localStorage.getItem('u_email')){
                        window.location.href = "auth/unlock.html"
                    }
                    else{
                        window.location.href = "auth/login.html"
                    }
                    
                }
            },
        })// ajax end
    }
})
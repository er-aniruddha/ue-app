$(document).ready(function() {
	$("#header").load('layouts/header.html')
    $("#sidebar").load('layouts/sidebar.html')   
    $("#footer").load('layouts/footer.html')     
    function loadInitial(argument) {
        $.ajax({
            method: "GET",
            url: base_url+"api/loan/accounts",
            dataType: "json",
            contentType: false,
            cache: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                'Accept': 'application/json',
                "Authorization": "Bearer " + access_token
            },
            success: function(response) { 
                $("#_lAmount").text(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(response.loanAmount))
                $("#_bAmount").text(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(response.loanBal))
                $("#_eAmount").text(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(response.totalEmi))
                let loanAccount = response.loanAccount
                if(loanAccount.length != 0){	
                	for(let count=0; count<loanAccount.length; count++){
                		if(loanAccount[count].loan_status == 1){
                            let tenure = loanAccount[count].month / 12
                            if(tenure < 1){
                                tenure = '0 year(s) and '+loanAccount[count].month+' month(s)'
                            }
                            else{
                                let month = loanAccount[count].month - parseInt(tenure)*12
                                tenure = parseInt(tenure)+' year(s) and '+month+' month(s)'
                            }
                            let loanType
                            if(loanAccount[count].loan_type == 1){
                                loanType = 'EMI'
                            }
                            else{
                                loanType = 'OMI'
                            }
                			$("#_loanAccounts").append('<div class="card cart-item mb-2" style="border: 1px solid #c2ffc2">'+
                                '<div class="card-body">'+
                                    '<div class="in">'+
                                        '<img src="img/loan-account.png" alt="customer" class="imaged">'+
                                        '<div class="row" style="margin-left: 10px;">'+
                                            '<h4 class="text-capitalize mb-1"><i class="bi bi-piggy-bank"></i></i>&nbsp;'+loanAccount[count].account_name+'<span class="text-success"> (Active)</span></h4>'+
                                            '<h5 class="text-muted">Purchase Date : <span class="inr-sign" style="float: right;">'+moment(loanAccount[count].date).format('DD-MM-YYYY')+'</span></h5>'+
                                            '<h5 class="text-muted text-warning">Loan Amount : <span class="inr-sign" style="float: right;">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(loanAccount[count].loan_amount)+'</span></h5>'+
                                                                                
                                            '<h5 class="text-muted">ROI : <span style="float: right;">'+loanAccount[count].interest_rate+' %</span></h5>'+
                                            '<h5 class="text-muted">Tenure : <span style="float: right;">'+tenure+'</span></h5>'+
                                            '<h5 class="text-muted text-info">'+loanType+' : <span class="inr-sign" style="float: right;">'+loanAccount[count].emi+'</span></h5>'+                                           
                                            '<h5 class="text-muted text-primary">Net Balance: <span class="inr-sign" style="float: right;">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(loanAccount[count].loan_balance)+'</span></h5>'+
                                        '</div>'+
                                        
                                    '</div>'+
                                    '<div class="cart-item-footer">'+                                                       
                                        '<a href="#'+loanAccount[count].cr_trnx_id+'" class="btn btn-block btn btn-outline-primary" >View</a>'+
                                    '</div>'+
                                '</div>'+
                            '</div>')
	                	}
                        else{
                            let tenure = loanAccount[count].month / 12
                            if(tenure < 1){
                                tenure = '0 year(s) and '+loanAccount[count].month+' month(s)'
                            }
                            else{
                                let month = loanAccount[count].month - parseInt(tenure)*12
                                tenure = parseInt(tenure)+' year(s) and '+month+' month(s)'
                            }
                            let loanType
                            if(loanAccount[count].loan_type == 1){
                                loanType = 'EMI'
                            }
                            else{
                                loanType = 'OMI'
                            }
                            $("#_loanAccounts").append('<div class="card cart-item mb-2" style="border: 1px solid #6C7C94 ">'+
                                '<div class="card-body">'+
                                    '<div class="in">'+
                                        '<img src="img/loan-account.png" alt="customer" class="imaged" style="background: #6C7C94;">'+
                                        '<div class="row" style="margin-left: 10px;">'+
                                            '<h4 class="text-capitalize mb-1 text-secondary"><i class="bi bi-piggy-bank"></i></i>&nbsp;'+loanAccount[count].account_name+'<span class="text-secondary"> (Closed)</span></h4>'+
                                            '<h5 class="text-muted text-secondary">Purchase Date : <span class="inr-sign" style="float: right;">'+moment(loanAccount[count].date).format('DD-MM-YYYY')+'</span></h5>'+
                                            '<h5 class="text-muted text-secondary">Loan Amount : <span class="inr-sign" style="float: right;">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(loanAccount[count].loan_amount)+'</span></h5>'+
                                                                                
                                            '<h5 class="text-muted text-secondary">ROI : <span style="float: right;">'+loanAccount[count].interest_rate+' %</span></h5>'+
                                            '<h5 class="text-muted text-secondary">Tenure : <span style="float: right;">'+tenure+'</span></h5>'+
                                            '<h5 class="text-muted text-secondary">'+loanType+' : <span class="inr-sign" style="float: right;">'+loanAccount[count].emi+'</span></h5>'+                                           
                                            '<h5 class="text-muted text-secondary">Net Balance: <span class="inr-sign" style="float: right;">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(loanAccount[count].loan_balance)+'</span></h5>'+
                                        '</div>'+
                                        
                                    '</div>'+
                                    '<div class="cart-item-footer">'+                                                       
                                        '<a href="#'+loanAccount[count].cr_trnx_id+'" class="btn btn-block btn btn-outline-secondary" >View</a>'+
                                    '</div>'+
                                '</div>'+
                            '</div>')
                        }
                	}
                }	                	
            	else{
                    $("#_loanAccounts").append('<h4 class="text-secondary" style="text-align: center; padding-top: 25%;">No Loan Account Found!!!</h4>')
                }
                $(".pageTitle").text('Open Orders')
                $('#loader').hide();
            }, //success end
            error: function(badRes,t) {
                // errortoast(badRes.statusText)
                if(navigator.onLine == false){
                    loadInitial()
                }
                if (badRes.status > 200) {
                    loadInitial()                            
                }
                if (badRes.status == 401) {
                    localStorage.removeItem('access_token');
                    if(localStorage.getItem('u_email')){
                        window.location.href = "auth/unlock.html"
                    }
                    else{
                        window.location.href = "auth/login.html"
                    }
                    
                }
            }, //ajax error end
        }) //ajax end
    }
    loadInitial()

    $(document).on("keyup","#search_input", function() {
        var value = $(this).val().toLowerCase();
        searchFunction(value)
    });  

    $(document).on('click','#headerCloseBtn',function(event){
        event.preventDefault()
        $("#search_input").val('')
        $("#search_input").attr('placeholder','Search...')
        $("#search").removeClass('show')
        var value = ''
        searchFunction(value)
    })

    function searchFunction(value) {
        $("#_loanAccounts ").filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });
    }
})//document ready end
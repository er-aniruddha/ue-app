    $(document).ready(()=>{
    $("#sidebar").load('layouts/sidebar.html')   
    $("#footer").load('layouts/footer.html')     
    var access_token = localStorage.getItem('access_token') 
    var sales,products,customerId,customerType,customerName,shopName,phone1,locality,prevBalance, trnxId;
    var inoviceBottomForm = {};
    var selectProductInfo = {}
    var allProductsInfo = [];
    /*------- View Start Here -------------*/
    /*------ Get Order Edit Information ---------*/
    let saletrnxId = window.location.hash.slice(1)
    function getOrderInformation() {
        $.ajax({
            method: "GET",
            url: base_url + "api/sale/order/show/"+saletrnxId,
            dataType: "json",
            processData: false,
            contentType: false,
            cache: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                'Accept': 'application/json',
                "Authorization": "Bearer " + access_token
            },
            success: function(sales) {      
            	for (var count = 0; count < sales.length; count++){
                    let disc,discPCT
                    if(sales[count].sale_discount > 0){
                        discPCT = '<td class="text-danger">'+parseFloat(sales[count].sale_discount_percentage).toFixed(2)+' %</td>'
                        disc = '<td class="inr-sign text-danger">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(sales[count].sale_discount)+'</td>'
                    }
                    else{
                        discPCT = discPCT = '<td class="text-danger">'+parseFloat(sales[count].sale_discount_percentage).toFixed(2)+' %</td>'
                        disc = '<td class="inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(sales[count].sale_discount)+'</td>'
                    }
            		$("#order_table tbody").append('<tr>'+
                                '<td><span style="margin-right: 150px;">'+sales[count].product_name+' - '+sales[count].brand_name+ '</span></td>'+
                                '<td>'+sales[count].sale_qty+' ('+sales[count].unit_code+')</td>'+
                                '<td class="inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(sales[count].sale_unit_price)+'</td>'+
                                discPCT+
                                disc+
                                '<td class="inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(sales[count].sale_amount)+'</td>'+                                        
                            '</tr>')
	                $('.invoice-to').html('<h4 class="text-capitalize"><i class="bi bi-shop"></i>&nbsp;'+sales[count].shop_name+'</h4>'+
	                                    '<h3 class="text-capitalize">'+sales[count].f_name+' '+sales[count].s_name+'</h3>'+
	                                    '<p class="text-capitalize"><i class="bi bi-telephone"></i>&nbsp;'+sales[count].phone_1+'</p>'+
	                                    '<p class="text-capitalize"><i class="bi bi-geo-alt"></i>&nbsp;'+sales[count].locality+'</p>')
	                $(".invoice-total").html('<ul class="listview transparent simple-listview">'+
	                                '<li>Round Off <span class="hightext inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(sales[count].sale_round_off)+'</span></li>'+
	                                '<li>Delivery Charges <span class="hightext inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(sales[count].sale_delivery_charges)+'</span></li>'+
	                                '<li>TAX <span class="hightext inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(sales[count].sale_gst_amount)+'</span></li>'+
	                                '<li>Total<span class="totaltext text-primary inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(sales[count].sale_total)+'</span></li>'+
	                                '<li>Prev. Balance<span class="hightext text-dark inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(sales[count].sale_prev_balance) +'</span></li>'+
	                                '<li>Received &#92; Paid <span class="hightext inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(sales[count].sale_received) +'</span></li>'+
	                                '<li>Balance <span class="hightext text-danger inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(sales[count].sale_balance) +'</span></li>'+
	                           '</ul>')

	                $(".total").html(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(sales[0].sale_total) )
	                $(".balance").html(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(sales[0].sale_balance) )
	                $("#itemCount").html(sales.length + " Item(s) <span style='font-size: 30px;font-weight: normal;'>|</span>")
                    $(".invoice-id").html('#OD-'+sales[0].sale_trnx_id)
	                $(".order-date").html('<p>Order Date : '+moment(sales[0].sale_order_date, 'YYYY-MM-DD').format("DD-MM-YYYY")+'</p>')

	               
	                if(sales[0].sale_payment_type == 1){
	                    $(".payment-type").html('<p>Payment Type : Cash</p>')
	                }
	                if(sales[0].sale_payment_type == 2){
	                    $(".payment-type").html('<p>Payment Type : Online</p>')
	                }
	                if(sales[0].sale_payment_type == 3){
	                    $(".payment-type").html('<p>Payment Type : Cheque</p>')
	                } 
                    if(sales[0].sale_payment_type == 4){
                        $(".payment-type").html('<p>Payment Type : No Payment</p>')
                    }
            	}
                
                $('#loader').hide();
            },
            error: function(badres) {
                errortoast(badres.statusText)
                if (navigator.onLine == false) {
                    productList();
                }
                if (badres.status > 200) {
                    productList();
                }
                if (badres.status == 401) {
                    localStorage.removeItem('access_token');
                    if (localStorage.getItem('u_email')) {
                        window.location.href = "auth/unlock.html"
                    } else {
                        window.location.href = "auth/login.html"
                    }

                }
            },
        })
    } // orderList function end
    getOrderInformation()
    /*------ Get Order Edit Information ---------*/    

    /*------- Order Convert to Purchase Start ------------*/
    var deliveryDate		    
    duDatepicker('#cnvtPurchaseBtn', {
        format: 'dd-mm-yyyy',cancelBtn: true,minDate:moment("2022-01-01"),maxDate:'today',
        // disabledDays: ['Sat', 'Sun'],
        events: {
            dateChanged: function (res) { 
                deliveryDate = new Date(res._date).getFullYear()+'-'+(new Date(res._date).getMonth()+1)+'-'+new Date(res._date).getDate();
                $("#confirmModal .message").html("Are you sure to save with this date "+res.date)
                $("#confirmModal .modal-title").text("Confirm Order : #OD-"+saletrnxId)
                $("#confirmModal").modal('show')  
                $("#confirmModal").modal('show')  
            }
        }
    })

    $(document).on('click','#orderConfirmBtn',(e)=>{
    	e.preventDefault()
    	$("#loader").show()
        $("#confirmModal .text-danger").html('')
        convertToPurchase()
    })

    function convertToPurchase() {
        $.ajax({
            type: 'POST',
            url: base_url + "api/sale/order/convert",
            data: { deliveryDate:deliveryDate, saleTrnxId:saletrnxId  },
            dataType: 'json',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                'Accept': 'application/json',
                "Authorization": "Bearer " + access_token
            },
            success: function(response) {
                $("#loader").hide()              
                if(response.success){
                    $('#successModal .modal-title').text(response.success)
                    $("#confirmModal").modal('hide') 
                    $("#successModal").modal('show')
                }

            }, // success end
            error: function(badRes) {
                $("#loader").hide()
                errortoast(badRes.statusText)
                if(navigator.onLine == false){
                    convertToPurchase();
                }
                if(badRes.status > 200){
                    convertToPurchase();
                }
                if (badRes.status == 401) {
                    localStorage.removeItem('access_token');
                    if(localStorage.getItem('u_email')){
                        window.location.href = "auth/unlock.html"
                    }
                    else{
                        window.location.href = "auth/login.html"
                    }

                }
            }, //ajax error end

        }); //Ajax End
    }

    $(document).on('click','#successModalOkBtn',()=>{
        window.location.href = document.referrer
    })
    /*------- Order Convert to Purchase End ------------*/    
})//document ready end
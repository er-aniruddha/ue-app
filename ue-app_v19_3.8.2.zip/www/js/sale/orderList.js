$(document).ready(function() {
	$("#header").load('layouts/header.html')
    $("#sidebar").load('layouts/sidebar.html')   
    $("#footer").load('layouts/footer.html')     
    var access_token = localStorage.getItem('access_token') 
    function loadInitial(argument) {
        $.ajax({
            method: "GET",
            url: base_url+"api/sale/order",
            dataType: "json",
            contentType: false,
            cache: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                'Accept': 'application/json',
                "Authorization": "Bearer " + access_token
            },
            success: function(response) { 
                let _orderList = response.saleOrderList;
                let _creditNoteList = response.creditNoteList;            	
            	_orderList = $.map(_orderList, function(value, index){
			        return [value];
			    });	
                _creditNoteList = $.map(_creditNoteList, function(value, index){
                    return [value];
                });			
            	if(_orderList.length == 0){
                    $("#_orders").append('<h4 class="text-secondary" style="text-align: center; padding-top: 25%;">No Order Placed !!!</h4>')
                }
              
                orderList(_orderList)
                creditNoteList(_creditNoteList)

                $(".pageTitle").text('Open Orders')
                $('#loader').hide();
            }, //success end
            error: function(badRes,t) {
                // errortoast(badRes.statusText)
                if(navigator.onLine == false){
                    loadInitial()
                }
                if (badRes.status > 200) {
                    loadInitial()                            
                }
                if (badRes.status == 401) {
                    localStorage.removeItem('access_token');
                    if(localStorage.getItem('u_email')){
                        window.location.href = "auth/unlock.html"
                    }
                    else{
                        window.location.href = "auth/login.html"
                    }
                    
                }
            }, //ajax error end
        }) //ajax end
    }
    

    function orderList(orderList) {
        let paymentType,thisSaletrnxId=0
        for(let count=0; count < orderList.length; count++){
            if(orderList[count].sale_payment_type == 1){
                paymentType = '<p class="mb-0">Payment Type : Cash</p>'
            }
            if(orderList[count].sale_payment_type == 2){
                paymentType = '<p class="mb-0">Payment Type : Online</p>'
            }
            if(orderList[count].sale_payment_type == 3){
                paymentType = '<p class="mb-0">Payment Type : Cheque</p>'
            }
            if(orderList[count].sale_payment_type == 4 || orderList[count].sale_payment_status == 0){
                paymentType = '<p class="mb-0">Payment Type : Not Paid</p>'
            } 
            $("#_orders").append('<div class="card cart-item mb-2" style="border:1px solid #c2ffc2;">'+
                                '<div class="card-body">'+
                                    '<div class="in">'+
                                        '<img src="img/avatar1.png" alt="customer" class="imaged">'+
                                        '<div class="text">'+
                                            '<h4 class="title text-capitalize"><i class="bi bi-shop"></i>&nbsp;'+orderList[count].shop_name+'</h4>'+
                                            '<p class="detail text-capitalize">&nbsp;'+orderList[count].f_name+' '+orderList[count].s_name+'</p>'+
                                            '<p class="detail text-capitalize"><i class="bi bi-telephone"></i>&nbsp;'+orderList[count].phone_1+'</p>'+
                                            '<p class="detail text-capitalize"><i class="bi bi-geo-alt"></i>&nbsp;'+orderList[count].locality+'</p>'+
                                        '</div>'+
                                        '<div class="text-right">'+
                                            '<p class="title mb-0 text-success">#OD-'+orderList[count].sale_trnx_id+'</p>'+
                                            '<p class="mb-0">Order Date: '+moment(orderList[count].sale_order_date).format('DD-MM-YYYY')+'</p>'+
                                            paymentType+    
                                            '<h5 class="text-secondary">Net Balance: <span class="inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(orderList[count].sale_balance)+'</span></h5>'+
                                        '</div>'+
                                        
                                    '</div>'+
                                    '<div class="cart-item-footer">'+                                                       
                                        '<a href="javascript:void(0)" class="btn btn-outline-danger btn-sm delete" data-saletrnxid="'+orderList[count].sale_trnx_id+'">Delete</a>'+
                                        '<a href="orderEdit.html#'+orderList[count].sale_trnx_id+'" class="btn btn-outline-warning btn-sm">Edit</a>'+
                                        '<a href="orderConvertToSale.html#'+orderList[count].sale_trnx_id+'" class="btn btn-outline-primary btn-sm" >View</a>'+
                                    '</div>'+
                                '</div>'+
                            '</div>')
        }
    }

    function creditNoteList(creditNoteList) {
        let paymentType,thisSaletrnxId=0
        for(let count=0; count < creditNoteList.length; count++){
            if(creditNoteList[count].sale_payment_type == 1){
                paymentType = '<p class="mb-0">Payment Type : Cash</p>'
            }
            if(creditNoteList[count].sale_payment_type == 2){
                paymentType = '<p class="mb-0">Payment Type : Online</p>'
            }
            if(creditNoteList[count].sale_payment_type == 3){
                paymentType = '<p class="mb-0">Payment Type : Cheque</p>'
            }
            if(creditNoteList[count].sale_payment_type == 4 || creditNoteList[count].cr_payment_status == 0){
                paymentType = '<p class="mb-0">Payment Type : Not Paid</p>'
            } 
            $("#_orders").append('<div class="card cart-item mb-2" style="border: 1px solid #FE9500E6;">'+
                                '<div class="card-body">'+
                                    '<div class="in">'+
                                        '<img src="img/avatar1.png" alt="customer" class="imaged">'+
                                        '<div class="text">'+
                                            '<h4 class="title text-capitalize"><i class="bi bi-shop"></i>&nbsp;'+creditNoteList[count].shop_name+'</h4>'+
                                            '<p class="detail text-capitalize">&nbsp;'+creditNoteList[count].f_name+' '+creditNoteList[count].s_name+'</p>'+
                                            '<p class="detail text-capitalize"><i class="bi bi-telephone"></i>&nbsp;'+creditNoteList[count].phone_1+'</p>'+
                                            '<p class="detail text-capitalize"><i class="bi bi-geo-alt"></i>&nbsp;'+creditNoteList[count].locality+'</p>'+
                                        '</div>'+
                                        '<div class="text-right">'+
                                            '<p class="title mb-0 text-warning">#CRN-OD-'+creditNoteList[count].cr_trnx_id+'</p>'+
                                            '<p class="mb-0">Order Date: '+moment(creditNoteList[count].cr_order_date).format('DD-MM-YYYY')+'</p>'+
                                            paymentType+    
                                            '<h5 class="text-secondary">Net Balance: <span class="inr-sign">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(creditNoteList[count].cr_balance)+'</span></h5>'+
                                        '</div>'+
                                        
                                    '</div>'+
                                    '<div class="cart-item-footer">'+                                                       
                                        '<a href="javascript:void(0)" class="btn btn-outline-danger btn-sm delete" data-saletrnxid="'+creditNoteList[count].cr_trnx_id+'">Delete</a>'+
                                        '<a href="orderEdit.html#'+creditNoteList[count].cr_trnx_id+'" class="btn btn-outline-warning btn-sm">Edit</a>'+
                                        '<a href="orderConvertToSale.html#'+creditNoteList[count].cr_trnx_id+'" class="btn btn-outline-primary btn-sm" >View</a>'+
                                    '</div>'+
                                '</div>'+
                            '</div>')
        }
    }

    loadInitial()


    /*------- Delete Order Start ------------*/
    let delOrderId;
    $(document).on('click','a.delete',function(){
        delOrderId = $(this).data('saletrnxid')
        $("#actionModal").modal('hide')
        $('#errorModal .modal-body').html("Are you sure to delete this order #OD-"+delOrderId+"??")                
        $("#errorModalFooter").remove()
        $("#errorModal .error-modal-content").append('<div class="modal-footer" id="errorModalFooter">'+
                '<div class="btn-inline">'+
                    '<button class="btn btn-text-danger" id="sureDelBtn">'+
                        '<i class="bi bi-trash"></i>'+
                        'DELETE </button>'+
                    '<button class="btn btn-text-primary" data-bs-dismiss="modal">'+
                        '<i class="bi bi-x-circle"></i>'+
                       ' CLOSE </button>'+
                '</div>'+
            '</div>')
        $("#errorModal").modal('show')
    })

    $(document).on('click','#sureDelBtn',function(event){
        event.preventDefault()
        $('#loader').show();
        sureDelteOrder()
    })

    function sureDelteOrder() {
        $.ajax({
            method: "GET",
            url: base_url+"api/sale/order/delete/"+delOrderId,
            dataType: "json",
            processData: false,
            contentType: false,
            cache: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                'Accept': 'application/json',
                "Authorization": "Bearer " + access_token
            },
            success:function(response){
                $("#errorModal").modal('hide')
                if(response.success){
                    notification(response.success)
                    $("#_orders").empty().append()                
                    loadInitial()
                }
                if(response.error){
                    notification(response.error)
                }
            },
            error:function(badRes){
                errortoast(badRes.statusText)
                if(navigator.onLine == false){
                    sureDelteOrder()
                }
                if (badRes.status > 200) {
                    sureDelteOrder()                            
                }
                if (badRes.status == 401) {
                    localStorage.removeItem('access_token');
                    if(localStorage.getItem('u_email')){
                        window.location.href = "auth/unlock.html"
                    }
                    else{
                        window.location.href = "auth/login.html"
                    }
                    
                }
            },
        })// ajax end
    }
    /*------- Delete Order End ------------*/
    $(document).on("keyup","#search_input", function() {
        var value = $(this).val().toLowerCase();
        searchFunction(value)
    });  

    $(document).on('click','#headerCloseBtn',function(event){
        event.preventDefault()
        $("#search_input").val('')
        $("#search_input").attr('placeholder','Search...')
        $("#search").removeClass('show')
        var value = ''
        searchFunction(value)
    })

    function searchFunction(value) {
        $("#_orders ").filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });
    }
})//document ready end
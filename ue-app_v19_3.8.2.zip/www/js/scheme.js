$(document).ready(function() {   
    $("#sidebar").load('layouts/sidebar.html')
    $("#footer").load('layouts/footer.html')   
    /*------- input[type='number'] can't be null -------*/
    const numInputs = document.querySelectorAll('input[type=number]')
    numInputs.forEach(function(input) {
      input.addEventListener('change', function(e) {
        if (e.target.value == '') {
          e.target.value = 0
          calculation()
        }
      })
    })
    /*------- input[type='number'] can't be null -------*/    
    $("#appHeader").removeClass('scrolled')
    var access_token = localStorage.getItem('access_token')
    var customerId = localStorage.getItem('customerID')
    var customerType = localStorage.getItem('customerType')
    var customerName = localStorage.getItem('customerName')
    var shopName = localStorage.getItem('shopName')
    var phone1 = localStorage.getItem('phoneNo1')
    var locality = localStorage.getItem('locality')
    var prevBalance = localStorage.getItem('balance')   

    loadInitial()
    loadTable()
    $("#schemeForm").change('#scheme_code',function(){
        var data = $("#scheme_code").val();
        if(data == "UEAR10"){
            $("#discount_percentage").val(10)
        }
        else if(data == "UEAR14"){
            $("#discount_percentage").val(14)    
        }
        else if(data == "UEAR20"){
            $("#discount_percentage").val(20)
        }
        else if(data == "UEAR30"){
            $("#discount_percentage").val(30)
        }
        else{
            $("#discount_percentage").val(0)
        }
        calculation()
    })
    function loadInitial(){
        $('#loader').show();
        $.ajax({
            method: "GET",
            url: base_url+"api/scheme/"+customerId,
            dataType: "json",
            processData: false,
            contentType: false,
            cache: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                'Accept': 'application/json',
                "Authorization": "Bearer " + access_token
            },
            success:function(response){
                $("#schemePurchase").html(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(response.purchaseAmount))
                $("#schemeDisc").html(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(response.discountedAmount))
                $("#prevBalance").html(new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(prevBalance))
                var ouDue = prevBalance - response.discountedAmount
                if(response.discountedAmount > prevBalance){
                    $("#ouDue").html('Over Due/ Under Due:<span class="text-danger inr-sign mx-2" style="float: right;">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(ouDue)+'<span>')
                }
                else{
                    $("#ouDue").html('Over Due/ Under Due:<span class="text-danger inr-sign mx-2" style="float: right;">'+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(ouDue)+'<span>')
                }
                $('#loader').hide();
            }, //success end
            error: function(badRes,t) {
                errortoast(badRes.statusText)
                if(navigator.onLine == false){
                    loadInitial()
                }
                if (badRes.status > 200) {
                    loadInitial()                            
                }
                if (badRes.status == 401) {
                    localStorage.removeItem('access_token');
                    if(localStorage.getItem('email')){
                        window.location.href = "auth/unlock.html"
                    }
                    else{
                        window.location.href = "auth/login.html"
                    }
                    
                }
            }, //ajax error end
        })
        
    }
    function loadTable() {
        schemeDataTable = $("#scheme_table").DataTable({
            "bPaginate": true,
            "bLengthChange": true,
            "bInfo": false,
            "searching": true,
            processing: true,
            responsive: true,
            serverSide: true,
            ajax: {
                url:  base_url+"api/scheme/table/data/"+customerId,
                dataType: "json",
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                    'Accept': 'application/json',
                    "Authorization": "Bearer " + access_token
                },
            },    
            columns: [{
                data: "DT_RowIndex",
                name: "DT_RowIndex",
                render: function(data){
                    return '<span class="text-sm">'+data+'</span>'
                }
            },{
                data: "scheme_code",
                name: "scheme_code",
                render: function(data, type, full, meta) {
                    return '<span class="text-sm item-badge badge text-uppercase bg-danger" >'+data+'</span><i class="bi bi-menu-up text-primary mx-2"></i>'
                },      
            }, {
                data: "date",
                name: "date",
                render: function(data, type, full, meta) {
                    return '<span class="text-sm text-capitalize" style="white-space:nowrap">'+moment(data).format('DD-MM-YYYY')+'<i class="bi bi-menu-up text-primary mx-2"></i></span>'                    
                },      
            },{
                data: "purchase_amount",
                name: "purchase_amount",
                render: function(data){
                    return '<span class="text-sm inr-sign" style="white-space:nowrap"> '+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
                }
            },{
                data: "discount_percentage",
                name: "discount_percentage",
                render: function(data){
                    return '<span class="text-sm" style="white-space:nowrap"> '+data+' %</span>'
                }
            },{
                data: "discounted_amount",
                name: "discounted_amount",
                render: function(data){
                    return '<span class="text-sm inr-sign" style="white-space:nowrap"> '+new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(data)+'</span>'
                }
            },{
                render: function(data){
                    return '<a class="text-sm text-danger mx-4" style="white-space:nowrap"><i class="bi bi-trash"></i></a>'
                }
            }   ],

        }); 
        
    }

    $('#cusDetails').html('<h4 class="text-capitalize"><i class="bi bi-shop"></i>&nbsp;' + shopName + '</h4>' +
        '<h3 class="text-capitalize">' + customerName + '</h3>' +
        '<p class="text-capitalize"><i class="bi bi-telephone"></i>&nbsp;' + phone1 + '</p>' +
        '<p class="text-capitalize"><i class="bi bi-geo-alt"></i>&nbsp;' + locality + '</p>')
   
    $(document).on('click', '#schemeModalBtn', function(event) {
        event.preventDefault()
        $("#customer_id").val(customerId)
        $("#purchase_amount, #discounted_amount").val('')
        $("#schemeForm .text-danger").html("")
        $("#closeBtn").show()
        $("#saveBtn").show()
        $("#updateBtn").hide() 
    })
    $("#schemeForm").on('keyup', '#purchase_amount', function(event) {
        event.preventDefault()
        calculation()
    })

    $("#schemeForm").on('keyup', '#discount_percentage', function(event) {
        event.preventDefault()
        calculation()
    })

    $("#schemeForm").on('click', '#closeBtn', function(event) {
        event.preventDefault()
        $("#_unit").empty().append()
        $("#schemeForm")[0].reset()
        $("#schemeModal").modal("hide")
    })

    $("#schemeForm").on('click',"#date",(e)=>{
        e.preventDefault()
        $("#schemeModal").modal('hide') 
    })

    duDatepicker('#date', {
        format: 'dd-mm-yyyy',cancelBtn: true,minDate:moment("2021-01-01"),maxDate:'today',
        // disabledDays: ['Sat', 'Sun'],
        events: {
            dateChanged: function (res) {                
                $("#paymentInModal #date").val(res.date)
                $("#schemeModal").modal('show')  
            }
        }
    })
    function calculation(){
        let purchaseAmount = $("#purchase_amount").val() 
        let percent = $("#discount_percentage").val() 
        let discount = (purchaseAmount*percent)/100;
        $("#discounted_amount").val(parseFloat(discount).toFixed(2));
    }   
    $("#schemeForm").on('click', '#saveBtn', function(event) {
        event.preventDefault()
        $('#loader').show();
        $("#schemeForm .text-danger").html("")
        var formData = new FormData($("#schemeForm")[0]);
        $.ajax({
            method: "POST",
            url: base_url+"api/scheme/new/purchase",
            data: formData,
            dataType: "json",
            processData: false,
            contentType: false,
            cache: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                'Accept': 'application/json',
                "Authorization": "Bearer " + access_token
            },
            success: function(response) {
                $("#loader").hide()      
                if(response.errors){
                    if(response.errors.date){
                        $("#date_error").text(response.errors.date[0])
                    }
                    if(response.errors.scheme_code){
                        $("#scheme_code_error").text(response.errors.scheme_code[0])
                    }
                    if(response.errors.purchase_amount){
                        $("#purchase_amount_error").text(response.errors.purchase_amount[0])
                    }
                    if(response.errors.discount_percentage){
                        $("#discount_percentage_error").text(response.errors.discount_percentage[0])
                    }                    
                    if(response.errors.message){
                        $("#schemeModal").modal('hide') 
                        errortoast(response.errors.message[0])
                    }
                }
                if(response.success){
                    $('#successModal .modal-title').text(response.success)
                    $("#successModal").modal('show')
                    $("#schemeModal").modal('hide')
                    loadInitial()
                    $('#scheme_table').DataTable().ajax.reload();
                }

            }, // success end
            error: function(badRes) {
                $("#loader").hide()
                errortoast(badRes.statusText)
                if(navigator.onLine == false){
                    loadInitial();
                }
                if(badRes.status > 200){
                    loadInitial();
                }
                if (badRes.status == 401) {
                    localStorage.removeItem('access_token');
                    if(localStorage.getItem('email')){
                        window.location.href = "auth/unlock.html"
                    }
                    else{
                        window.location.href = "auth/login.html"
                    }

                }
            }, //ajax error end

        }); //Ajax End
     
    })

    $("#scheme_table tbody").on('click','tr td:not(:last-child)',function() {       
        let data = schemeDataTable.row( this ).data()
        $("#scheme_code").val(data.scheme_code)
        $("#date").val(moment(data.date).format("DD-MM-YYYY"))
        $("#purchase_amount").val(data.purchase_amount)
        $("#discount_percentage").val(data.discount_percentage)
        $("#discounted_amount").val(data.discounted_amount)
        $("#id").val(data.id)
        $("#closeBtn").show()
        $("#saveBtn").hide()
        $("#updateBtn").show() 
        $("#schemeModal").modal('show')
    })

    $("#scheme_table tbody").on('click','tr td:last-child',function() { 
        let data = schemeDataTable.row( this ).data()
        $("#delModal .modal-title").text(moment(data.date).format("DD-MM-YYYY"))
        $("#del_id").val(data.id)
        $("#delModal").modal('show')
    })

    $("#schemeForm").on('click', '#updateBtn', function(event) {
        event.preventDefault()
        $('#loader').show();
        $("#schemeForm .text-danger").html("")
        var formData = new FormData($("#schemeForm")[0]);
        $.ajax({
            method: "POST",
            url: base_url+"api/scheme/edit/purchase",
            data: formData,
            dataType: "json",
            processData: false,
            contentType: false,
            cache: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                'Accept': 'application/json',
                "Authorization": "Bearer " + access_token
            },
            success: function(response) {
                $("#loader").hide()      
                if(response.errors){
                    if(response.errors.date){
                        $("#date_error").text(response.errors.date[0])
                    }
                    if(response.errors.scheme_code){
                        $("#scheme_code_error").text(response.errors.scheme_code[0])
                    }
                    if(response.errors.purchase_amount){
                        $("#purchase_amount_error").text(response.errors.purchase_amount[0])
                    }
                    if(response.errors.discount_percentage){
                        $("#discount_percentage_error").text(response.errors.discount_percentage[0])
                    }                    
                    if(response.errors.message){
                        $("#schemeModal").modal('hide') 
                        errortoast(response.errors.message[0])
                    }
                }
                if(response.success){
                    $('#successModal .modal-title').text(response.success)
                    $("#successModal").modal('show')
                    $("#schemeModal").modal('hide')
                    loadInitial()
                    $('#scheme_table').DataTable().ajax.reload();
                }

            }, // success end
            error: function(badRes) {
                $("#loader").hide()
                errortoast(badRes.statusText)
                if(navigator.onLine == false){
                    loadInitial();
                }
                if(badRes.status > 200){
                    loadInitial();
                }
                if (badRes.status == 401) {
                    localStorage.removeItem('access_token');
                    if(localStorage.getItem('email')){
                        window.location.href = "auth/unlock.html"
                    }
                    else{
                        window.location.href = "auth/login.html"
                    }

                }
            }, //ajax error end

        }); //Ajax End     
    })


    $("#delModal").on('click','#delConfirmBtn',function(){
        $('#loader').show();
        var formData = new FormData($("#delForm")[0]);
        $.ajax({
            method: "POST",
            url: base_url+"api/scheme/delete/purchase",
            data: formData,
            dataType: "json",
            processData: false,
            contentType: false,
            cache: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                'Accept': 'application/json',
                "Authorization": "Bearer " + access_token
            },
            success: function(response) {
                $("#loader").hide()      
                if(response.errors){                            
                    if(response.errors.message){
                        $("#delModal").modal('hide') 
                        errortoast(response.errors.message[0])
                    }
                }
                if(response.success){
                    $('#successModal .modal-title').text(response.success)
                    $("#successModal").modal('show')
                    $("#delModal").modal('hide')
                    loadInitial()
                    $('#scheme_table').DataTable().ajax.reload();
                }

            }, // success end
            error: function(badRes) {
                $("#loader").hide()
                errortoast(badRes.statusText)
                if(navigator.onLine == false){
                    loadInitial();
                }
                if(badRes.status > 200){
                    loadInitial();
                }
                if (badRes.status == 401) {
                    localStorage.removeItem('access_token');
                    if(localStorage.getItem('email')){
                        window.location.href = "auth/unlock.html"
                    }
                    else{
                        window.location.href = "auth/login.html"
                    }

                }
            }, //ajax error end
        }); //Ajax End 
    })
       
})